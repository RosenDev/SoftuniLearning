﻿namespace MyApp.Core.Interfaces
{
    public interface IEngine
    {
        void Run();
    }
}