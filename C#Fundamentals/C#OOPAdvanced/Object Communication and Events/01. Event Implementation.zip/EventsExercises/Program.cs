﻿using System;

namespace EventsExercises
{
    class Program
    {
        static void Main(string[] args)
        {
           
            var handler=new Handler();
            var disp = new Dispatcher();
            disp.NameChange += new NameChangeEventHandler(handler.OnDispatcherNameChange);
            var name = Console.ReadLine();
            while (name!="End")
            {
                disp.Name = name;

                name = Console.ReadLine();
            }
        }
    }
}
