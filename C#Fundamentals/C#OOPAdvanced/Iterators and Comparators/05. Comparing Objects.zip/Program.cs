﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var people = new List<Person>();
            var equal = 0;
            var notEqual = 0;
            
            var input = Console.ReadLine();
            while (input!="END")
            {
                people.Add(new Person(input.Split(" ",StringSplitOptions.RemoveEmptyEntries)[0],int.Parse(input.Split(" ", StringSplitOptions.RemoveEmptyEntries)[1]), input.Split(" ", StringSplitOptions.RemoveEmptyEntries)[2]));
                input = Console.ReadLine();
            }

            var nth = int.Parse(Console.ReadLine());
            foreach (var person in people)
            {
                if (people[nth-1].CompareTo(person)==0)
                {
                    equal++;
                }
                else
                {
                    notEqual++;
                }
            }

            Console.WriteLine(equal>1?$"{equal} {notEqual} {people.Count}":$"No matches");
        }

    }
}

