﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace IteratorsAndComparators
{
    public class Stack<T>:IEnumerable<T>
    {
        private Node<T> top;

        public Stack()
        {
            top = null;
        }

        public T Pop()
        {

            var element = this.top!=null?top:throw new InvalidOperationException("No elements");
            var current = top;
            current = null;
            top = top.Prev;
            return element.Value;
        }
        public void Push(T element)
        {
            var node = new Node<T>(element);
            if (top==null)
            {
                this.top=node;
            }
            else
            {
                Node<T> current = top;
                this.top=node;
                this.top.Prev = current;
            }
        }
        private class Node<T>
        {
            public T Value { get; set; }
            public Node<T> Prev { get; set; }

            public Node(T value)
            {
                Value = value;
                Prev = null;
            }
        }
        public IEnumerator<T> GetEnumerator()
        {
            var element = top;
            while (element!=null)
            {

                yield return element.Value;
                element = element.Prev;

            }   
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}