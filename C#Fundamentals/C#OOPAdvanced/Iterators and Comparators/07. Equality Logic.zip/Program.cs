﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var sortedset= new SortedSet<Person>();
            var hasSet=new HashSet<Person>();
            var lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                var input = Console.ReadLine();
                sortedset.Add(new Person(input.Split(" ")[0], int.Parse(input.Split(" ")[1])));
                hasSet.Add(new Person(input.Split(" ")[0], int.Parse(input.Split(" ")[1])));
            }

            Console.WriteLine(hasSet.Count);
            Console.WriteLine(sortedset.Count);
        }
    }
}
