﻿using System;

namespace IteratorsAndComparators
{
    public class Person:IComparable<Person>
    {
        public override string ToString()
        {
            return $"{Name} {Age}";
        }

        public override bool Equals(object obj)
        {
            if (obj is Person person)
            {
                return Name == person.Name && Age == person.Age;
            }

            return false;
        }

        public override int GetHashCode()
        {
            return Name.GetHashCode() + Age.GetHashCode();
        }

        public string Name{ get; set; }
        public int  Age { get; set; }
        
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
       
        }

        public int CompareTo(Person other)
        {
            if (ReferenceEquals(this, other)) return 0;
            if (ReferenceEquals(null, other)) return 1;
            var nameComparison = string.Compare(Name, other.Name, StringComparison.Ordinal);
            if (nameComparison != 0) return nameComparison;
            return Age.CompareTo(other.Age);
        }
    }
}