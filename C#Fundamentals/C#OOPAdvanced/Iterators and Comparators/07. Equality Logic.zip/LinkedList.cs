﻿using System.Collections;
using System.Collections.Generic;

namespace IteratorsAndComparators
{
    public class LinkedList<T>:IEnumerable<T>
    {
        //TODO WORK!
        private class Node<T>
        {
            public T Value { get; set; }
            public Node<T> Next { get; set; }

        }

        public IEnumerator<T> GetEnumerator()
        {
            throw new System.NotImplementedException();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}