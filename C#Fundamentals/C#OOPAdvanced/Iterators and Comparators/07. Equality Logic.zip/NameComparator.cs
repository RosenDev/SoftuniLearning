﻿using System.Collections.Generic;
using System.Linq;

namespace IteratorsAndComparators
{
    public class NameComparator:IComparer<Person>
    {
        public int Compare(Person x, Person y)
        {
            return x.Name.Length.CompareTo(y.Name.Length) == 0
                ? x.Name.ToLower().First().CompareTo(y.Name.ToLower().First())
                : x.Name.Length.CompareTo(y.Name.Length);
        }
    }
}