﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace IteratorsAndComparators
{
    public class ListyIterator<T>:IEnumerable<T>
    {
        private List<T> items { get; set; }
        private int count;

        public ListyIterator()
        {
            
            items=new List<T>();
        }

        public ListyIterator(IEnumerable<T>list)
        {
            items = list.ToList();
        }

        public bool HasNext()
        {
            return count+1 < items.Count;
        }

        public bool Move()
        {
            if (HasNext())
            {
                count++;
                return true;
            }

            return false;
        }

        public void Print()
        {
            try
            {
                Console.WriteLine(items[count]);
            }
            catch (Exception)
            {

                Console.WriteLine($"Invalid Operation!");

            }
        }

        public IEnumerator<T> GetEnumerator()
        {
            foreach (var item in items)
            {
                yield return item;
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}