﻿using System;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var stack = new Stack<string>();
            var input = Console.ReadLine();
            while (input!="END")
            {
                switch (input)
                {
                    case "Pop":
                        try
                        {
                            stack.Pop();


                        }
                        catch (InvalidOperationException e)
                        {
                            Console.WriteLine(e.Message);
                        
                        }
                        break;
                    default:
                        var arr = input.Substring(5, input.Length-5).Split(", ");
                        foreach (var s in arr)
                        {
                            stack.Push(s);
                        }
                        break;
                }

                input = Console.ReadLine();
            }

            try
            {
                foreach (var VARIABLE in stack)
                {
                    Console.WriteLine(VARIABLE);
                }
                foreach (var VARIABLE in stack)
                {
                    Console.WriteLine(VARIABLE);
                }
            }
            catch (Exception)
            {
          
          
            }
         
        }

    }
}

