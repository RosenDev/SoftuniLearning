﻿using System;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var cmd = Console.ReadLine();
            var lake = new Lake(cmd.Split(", ").Select(int.Parse).ToList());
            Console.WriteLine(String.Join(", ",lake));
        }

    }
}

