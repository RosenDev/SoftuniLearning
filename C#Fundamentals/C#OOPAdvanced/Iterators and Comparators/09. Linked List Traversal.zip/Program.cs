﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new LinkedList<string>();
            var lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                var cmd = Console.ReadLine().Split();
                if (cmd[0]=="Add")
                {
                    list.Add(cmd[1]);
                }

                else
                {
                    list.Remove(cmd[1]);
                }

            }

            Console.WriteLine(list.Count);
            Console.WriteLine(String.Join(" ",list));
        }
    }
}
