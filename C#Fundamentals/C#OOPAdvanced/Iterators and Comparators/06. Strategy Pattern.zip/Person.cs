﻿using System;

namespace IteratorsAndComparators
{
    public class Person
    {
        public override string ToString()
        {
            return $"{Name} {Age}";
        }

        public string Name{ get; set; }
        public int  Age { get; set; }
        
        public Person(string name, int age)
        {
            Name = name;
            Age = age;
       
        }
        
    }
}