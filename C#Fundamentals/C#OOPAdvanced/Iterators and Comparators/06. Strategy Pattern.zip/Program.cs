﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Xml;
using System.Xml.Schema;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            var nameSort = new SortedSet<Person>(new NameComparator());
            var ageSort = new SortedSet<Person>(new AgeComparator());
            var lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                var input = Console.ReadLine();
                nameSort.Add(new Person(input.Split(" ")[0], int.Parse(input.Split(" ")[1])));
                ageSort.Add(new Person(input.Split(" ")[0], int.Parse(input.Split(" ")[1])));

            }

            foreach (var person in nameSort)
            {
                Console.WriteLine(person);
            }

            foreach (var person in ageSort)
            {

                Console.WriteLine(person);
            }
        }
    }
}
