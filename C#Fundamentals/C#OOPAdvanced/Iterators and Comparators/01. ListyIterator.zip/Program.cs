﻿using System;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace IteratorsAndComparators
{
    class Program
    {
        static void Main(string[] args)
        {
            ListyIterator<string> iterator = null;
            var input = Console.ReadLine();
            while (input!="END")
            {
                var parts = input.Split(" ");
                switch (parts[0])
                {
                    case "Create":
                        
                        iterator=parts.Length>1?new ListyIterator<string>(parts.Skip(1).ToArray()):new ListyIterator<string>();
                        break;
                    case "HasNext":

                        Console.WriteLine(iterator?.HasNext());
                        break;
                    case "Move":
                        Console.WriteLine(iterator?.Move());
                        break;
                    case "Print":
                        iterator.Print();
                        break;

                      
                }

                input = Console.ReadLine();
            }

        }
    }

}