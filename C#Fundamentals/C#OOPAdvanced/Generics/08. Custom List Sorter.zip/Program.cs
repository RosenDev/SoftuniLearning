﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {var list = new List<string>();

            var command = Console.ReadLine();
            while (command!="END")
            {
                var parts = command.Split();
                var cmd = parts[0];
                switch (cmd)
                {
                    case "Add":
                        list.Add(parts[1]);
                        break;
                    case "Remove":
                        list.Remove(int.Parse(parts[1]));
                        break;
                    case "Contains":
                        Console.WriteLine(list.Contains(parts[1]));
                        break;
                    case "Max":
                        Console.WriteLine(list.Max());
                        break;
                    case "Min":
                        Console.WriteLine(list.Min());

                        break;
                    case "Greater":
                        Console.WriteLine(list.CountGreaterThan(parts[1]));
                        break;
                    case "Swap":
                        list.Swap(int.Parse(parts[1]),int.Parse(parts[2]));
                        break;
                    case "Print":
                        foreach (var VARIABLE in list)
                        {
                            Console.WriteLine(VARIABLE);
                        }
                        break;
                    case "Sort":
                        list.Sort();
                        break;


                }

                command = Console.ReadLine();
            }
        }

     
    }
  
}
