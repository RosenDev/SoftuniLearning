﻿using System;
using System.Linq;

namespace GenericBoxOfString
{
    public static class Sorter
    {
        public static void Sort<T>(this List<T>list)where T:IComparable<T>
        {
            for (int i = 0; i < list.Count; i++)
            {
                for (int j = i+1; j < list.Count; j++)
                {
                    if (list[i].CompareTo(list[j]) >0)
                    {
                        list.Swap(i, j);
                    }
                }
                
                
            }
         
        }
    }
}