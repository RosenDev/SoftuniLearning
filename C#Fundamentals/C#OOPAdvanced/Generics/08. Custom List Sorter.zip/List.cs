﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    public class List<T>:ICustomList<T>,IEnumerable<T> where T :IComparable<T>
    {
        private System.Collections.Generic.List<T> items;
        public int Count
        {
            get => items.Count;
         
        }

        public T this[int index] { get=>items[index]; set=>items[index]=value; }
        public void Add(T element)
        {
            items.Add(element);
        }

        public T Remove(int index)
        {
            var element = items[index];
            items.RemoveAt(index);
            
            return element;
        }

        public bool Contains(T element)
        {
            return items.Contains(element);
        }

        public T Min()
        {
            return items.Min();
        }

        public T Max()
        {
            return items.Max();
        }

        public void Swap(int index1, int index2)
        {
            var temp = items[index1];
            items[index1] = items[index2];
            items[index2] = temp;

        }

        public int CountGreaterThan(T element)
        {
            var count = 0;
            foreach (var item in items)
            {
                if (element.CompareTo(item)<0)
                {
                    count++;
                }
                
            }

            return count;
        }

        public List()
        {
            items=new System.Collections.Generic.List<T>();
        }

        public IEnumerator<T> GetEnumerator()
        {
            return items.GetEnumerator();
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return GetEnumerator();
        }
    }
}