﻿namespace GenericBoxOfString
{
    public interface ITreeTuple<TFirst,TSecond,TThird>
    {
        TFirst Item1 { get; }
        TSecond Item2 { get; }
        TThird Item3 { get; }
    }
}