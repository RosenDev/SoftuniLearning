﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {

            var line1 = Console.ReadLine().Split();
       
            var line2 = Console.ReadLine().Split();
            var line3 = Console.ReadLine().Split();
     var tuple1 = new TreeTuple<string,string,string>($"{line1[0]} {line1[1]}",line1[2],line1[3]);
            var tuple2= new TreeTuple<string, int,bool>(line2[0],int.Parse(line2[1]),line2[2]=="drunk");
            var tuple3 = new TreeTuple<string, double, string>(line3[0], double.Parse(line3[1]), line3[2]);
            Console.WriteLine(tuple1);
            Console.WriteLine(tuple2);
            Console.WriteLine(tuple3);

        }

     
    }
  
}
