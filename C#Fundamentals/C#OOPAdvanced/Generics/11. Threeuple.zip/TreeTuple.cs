﻿namespace GenericBoxOfString
{
    public class TreeTuple<TFirst,TSecond,TThird>:ITreeTuple<TFirst,TSecond,TThird>
    {
        public TFirst Item1 { get; set; }
        public TSecond Item2 { get; set; }
        public TThird Item3 { get; set; }

        public TreeTuple(TFirst item1, TSecond item2,TThird item3)
        {
            Item1 = item1;
            Item2 = item2;
            Item3 = item3;
        }

        public override string ToString()
        {
            return $"{Item1} -> {Item2} -> {Item3}";
        }
    }
}