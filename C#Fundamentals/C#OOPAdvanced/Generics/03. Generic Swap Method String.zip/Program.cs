﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
            var list = new List<Box<string>>();
            var rows = int.Parse(Console.ReadLine());
            for (int i = 0; i < rows; i++)
            {
                var input = Console.ReadLine();
                list.Add(new Box<string>(input));
              
            }

            var indexes = Console.ReadLine()
                .Split(" ", StringSplitOptions.RemoveEmptyEntries)
                .Select(int.Parse)
                .ToArray();
            Swap(list,indexes[0],indexes[1]);
            Console.WriteLine(string.Join("\n", list));

        }

        static void Swap<T>(List<Box<T>> elements, int first, int second)
        {
            var temp = elements[first];
            elements[first] = elements[second];
            elements[second] = temp;

        }
    }
  
}
