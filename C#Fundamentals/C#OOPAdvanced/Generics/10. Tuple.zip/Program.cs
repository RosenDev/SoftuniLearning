﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {

            var line1 = Console.ReadLine().Split();
            var tuple1 = new GenericBoxOfString.Tuple<string, string>($"{line1[0]} {line1[1]}", line1[2]);
            var line2 = Console.ReadLine().Split();
            var line3 = Console.ReadLine().Split();
            var tuple2= new GenericBoxOfString.Tuple<string,int>(line2[0],int.Parse(line2[1]));
            var tuple3= new GenericBoxOfString.Tuple<int,double>(int.Parse(line3[0]),double.Parse(line3[1]));
            Console.WriteLine(tuple1);
            Console.WriteLine(tuple2);
            Console.WriteLine(tuple3);
        }

     
    }
  
}
