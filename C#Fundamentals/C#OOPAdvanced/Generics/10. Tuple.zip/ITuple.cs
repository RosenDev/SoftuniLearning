﻿namespace GenericBoxOfString
{
    public interface ITuple<TFirst,TSecond>
    {
        TFirst Item1 { get; }
        TSecond Item2 { get; }
    }
}