﻿using System;
using System.Collections.Generic;
using System.Text;

namespace GenericBoxOfString
{
    public class Box<T> where T:IComparable<T>
    {
        public List<T> Items { get; set; }
        public Box(List<T>items)
        {
            Items = items;
        }

        
    }
}