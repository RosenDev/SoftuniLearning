﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace GenericBoxOfString
{
    class Program
    {
        static void Main(string[] args)
        {
           var list= new List<double>();
            var rows = int.Parse(Console.ReadLine());
            for (int i = 0; i < rows; i++)
            {
                var input = double.Parse(Console.ReadLine());
               list.Add(input);
              
            }
            var box = new Box<double>(list);
            var element = double.Parse(Console.ReadLine());
            Console.WriteLine(Count(box,element));


        }

        public static int Count<T>(Box<T>box, T element) where T:IComparable<T>
        {
            var count = 0;
            foreach (var boxItem in box.Items)
            {

                if (element.CompareTo(boxItem)<0)
                {
                    count++;
                }
            }

            return count;
        }

    }
  
}
