﻿namespace _03BarracksFactory.Contracts
{
    public interface IAttacker
    {
        int AttackDamage { get; }
    }
}
