﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Interfaces
{
    public interface IGem
    {
         int Strength { get;}   
        int Agility { get; }
        int Vitality { get; }
        Clarity Clarity { get; }
    }
}