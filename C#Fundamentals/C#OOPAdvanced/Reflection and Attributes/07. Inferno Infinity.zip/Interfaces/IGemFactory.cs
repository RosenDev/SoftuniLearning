﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Interfaces
{
    public interface IGemFactory
    {
        IGem CreateGem(string type,Clarity clarity);
    }
}