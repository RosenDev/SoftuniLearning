﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Interfaces
{
    public interface IWeaponFactory
    {
        IWeapon CreateWeapon(string type, string name, Rarity rarity);
    }
}