﻿using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity.Classes
{
    public class Gem:IGem
    {
        public int Strength { get; protected set; }
        public int Agility { get; protected set; }
        public int Vitality { get; protected set; }
        public Clarity Clarity { get; }

        public Gem(int strength, int agility, int vitality,Clarity clarity)
        {
            Clarity = clarity;
            Strength = strength+(int)Clarity;
            Agility = agility+(int)Clarity;
            Vitality = vitality+(int)Clarity;
        }
    }
}