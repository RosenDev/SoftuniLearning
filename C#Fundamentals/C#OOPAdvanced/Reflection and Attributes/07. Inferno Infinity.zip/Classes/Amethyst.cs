﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Classes
{
    public class Amethyst:Gem
    {
        public Amethyst(Clarity clarity) : base(2,8,4,clarity)
        {
        }
    }
}