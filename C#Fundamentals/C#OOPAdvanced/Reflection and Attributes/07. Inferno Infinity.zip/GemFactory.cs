﻿using System;
using System.Linq;
using System.Reflection;
using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity
{
    public class GemFactory:IGemFactory
    {
        public IGem CreateGem(string type, Clarity clarity)
        {
            var typeN = Assembly.GetCallingAssembly().GetTypes().FirstOrDefault(x => x.Name == type);
            return (IGem) Activator.CreateInstance(typeN, clarity);
        }
    }
}