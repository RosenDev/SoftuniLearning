﻿using System;
using System.Collections.Generic;
using System.Linq;
using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity
{
  public class Program
    {
        static void Main(string[] args)
        {IGemFactory gemFactory = new GemFactory();
           IWeaponFactory factory = new WeaponFactory();
            var weapons = new List<IWeapon>();
            var command = Console.ReadLine();
            while (command!="END")
            {

                var parts = command.Split(";");
                var cmd = parts[0];
                switch (cmd)
                {
                    case "Create":
                        var type = parts[1].Split()[1];
                        var rarity = Enum.Parse<Rarity>(parts[1].Split()[0]);
                       var weapon= factory.CreateWeapon(type, parts[2], rarity);
                        weapons.Add(weapon);
                        break;
                    case "Add":
                        var gem = gemFactory.CreateGem(parts[3].Split()[1], Enum.Parse<Clarity>(parts[3].Split()[0]));
                        try
                        {
                            weapons.Find(x => x.Name == parts[1]).Sockets[int.Parse(parts[2])] = gem;
                        }
                        catch (Exception)
                        {
                            command = Console.ReadLine();

                            continue;

                        }

                        break;
                    case "Remove":
                        weapons.Find(x => x.Name == parts[1]).Sockets[int.Parse(parts[2])] = null;
                        break;
                    case "Print":
                        Console.WriteLine(weapons.Find(x=>x.Name==parts[1]));
                        break;
                        
                }
                command = Console.ReadLine();
            }

        }
    }
}
