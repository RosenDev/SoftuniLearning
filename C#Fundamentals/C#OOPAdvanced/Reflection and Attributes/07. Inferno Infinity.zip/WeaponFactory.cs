﻿using System;
using System.Linq;
using System.Reflection;
using System.Runtime.InteropServices.ComTypes;
using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity
{
    public class WeaponFactory:IWeaponFactory
    {
        public IWeapon CreateWeapon(string type, string name, Rarity rarity)
        {
            var typeIn = Assembly.GetCallingAssembly().GetTypes().FirstOrDefault(x => x.Name == type);
            return (IWeapon) Activator.CreateInstance(typeIn,new object[]{name,rarity});
        }
    }
}