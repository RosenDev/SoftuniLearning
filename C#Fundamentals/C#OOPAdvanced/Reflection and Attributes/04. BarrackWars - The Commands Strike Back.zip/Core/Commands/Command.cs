﻿using System.Windows.Input;
using _03BarracksFactory.Contracts;

namespace _03BarracksFactory.Core.Commands
{
    public abstract class Command:IExecutable
    {
        public string[] Data
        {
            get => data;
           private set => data = value;
        }

        public IRepository Repository
        {
            get => repository;
         private set => repository = value;
        }

        public IUnitFactory UnitFactory
        {
            get => unitFactory;
            private set => unitFactory = value;
        }

        private string[] data;
        private IRepository repository;
        private IUnitFactory unitFactory;
        protected Command(string[] data, IRepository repository,IUnitFactory unitFactory)
        {
            Data = data;
            Repository = repository;
            UnitFactory = unitFactory;
        }
        public abstract string Execute();



    }
}