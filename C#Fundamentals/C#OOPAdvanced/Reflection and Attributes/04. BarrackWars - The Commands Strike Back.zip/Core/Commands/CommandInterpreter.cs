﻿using System;
using System.Linq;
using System.Reflection;
using _03BarracksFactory.Contracts;
using _03BarracksFactory.Core.Factories;
using _03BarracksFactory.Data;

namespace _03BarracksFactory.Core.Commands
{
    public class CommandInterpreter:ICommandInterpreter
    {
        private IUnitFactory unitFactory;
        private IRepository repository;
        public CommandInterpreter(IUnitFactory unitFactory, IRepository repository)
        {
            this.unitFactory = unitFactory;
            this.repository = repository;
        }
        public IExecutable InterpretCommand(string[] data, string commandName)
        {
            var commandType = Assembly.GetCallingAssembly().GetTypes().FirstOrDefault(x => x.Name.ToLower() == commandName);
            return (IExecutable)Activator.CreateInstance(commandType,data,repository,unitFactory);
        }
    }
}