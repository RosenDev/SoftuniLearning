﻿using System.Linq;

namespace _03BarracksFactory.Core
{
    using System;
    using Contracts;

    class Engine : IRunnable
    {
        
        private ICommandInterpreter interpreter;

        public Engine(ICommandInterpreter interpreter)
        {
            
            this.interpreter = interpreter;
        }

        public void Run()
        {
            while (true)
            {
                try
                {
                    string input = Console.ReadLine();
                    string[] data = input.Split();
                    string commandName = data[0];
                    string result = InterpredCommand(data.Skip(1).ToArray(), commandName);
                    Console.WriteLine(result);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        // TODO: refactor for Problem 4
        private string InterpredCommand(string[] data, string commandName)
        {
            //string result = string.Empty;
            //switch (commandName)
            //{
            //    case "add":
                
            //        break;
            //    case "report":
                    
            //        break;
            //    case "fight":
            //        Environment.Exit(0);
            //        break;
            //    default:
            //        throw new InvalidOperationException("Invalid command!");
            //}
            //return result;
            return interpreter.InterpretCommand(data, commandName).Execute();
        }


    


       
    }
}
