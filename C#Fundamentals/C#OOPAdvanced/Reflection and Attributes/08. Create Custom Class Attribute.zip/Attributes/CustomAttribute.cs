﻿using System;
using System.Collections.Generic;

namespace InfernoInfinity.Attributes
{[AttributeUsage(AttributeTargets.Class,AllowMultiple = true,Inherited = false)]
    public class CustomAttribute:Attribute
    {
        public string Author { get; private set; }
        public int Revsion { get; private set; }
        public string Description { get; private set; }

        public List<string> Reviewers { get; private set; }

        public CustomAttribute(string author, int revsion, string description, params string[] reviewers)
        {
            Author = author;
            Revsion = revsion;
            Description = description;
            Reviewers = new List<string>(reviewers);
        }
    }
}