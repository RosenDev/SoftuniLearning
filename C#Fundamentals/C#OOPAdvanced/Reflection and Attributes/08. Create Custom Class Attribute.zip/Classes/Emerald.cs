﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Classes
{
    public class Emerald:Gem
    {
        public Emerald(Clarity clarity) : base(1, 4,9,clarity)
        {
        }
    }
}