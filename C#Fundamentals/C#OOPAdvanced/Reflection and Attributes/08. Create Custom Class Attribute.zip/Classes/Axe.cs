﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Classes
{
    public class Axe:Weapon
    {
        public Axe(string name, Rarity rarity) : base(name,5,10,4, rarity)
        {
        }
    }
}