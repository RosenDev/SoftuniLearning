﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Classes
{
    public class Ruby:Gem
    {
        public Ruby(Clarity clarity) : base(7, 2, 5,clarity)
        {
        }
    }
}