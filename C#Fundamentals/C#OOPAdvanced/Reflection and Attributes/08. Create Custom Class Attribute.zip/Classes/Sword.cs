﻿using InfernoInfinity.Enums;

namespace InfernoInfinity.Classes
{
    public class Sword:Weapon
    {
        public Sword(string name, Rarity rarity) : base(name,4,6,3, rarity)
        {
        }
    }
}