﻿using System.Collections.Generic;
using System.Linq;
using InfernoInfinity.Attributes;
using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity.Classes
{
    [Custom("Pesho",3, "Used for C# OOP Advanced Course - Enumerations and Attributes.", "Pesho", "Svetlio")]
    public abstract class Weapon:IWeapon
        
    {
        public string Name { get; set; }
        public int MinDamage { get; }
        public int MaxDamage { get; }
        public IGem[] Sockets { get; private set; }
        public Rarity Rarity { get; }

        public Weapon(string name,int minDamage, int maxDamage, int socketsCount, Rarity rarity)
        {
            Name = name;
            Rarity = rarity;
            MinDamage = minDamage * (int)rarity;
            MaxDamage = maxDamage * (int)rarity;
            Sockets = new IGem[socketsCount];
            
        }

        public override string ToString()
        {
            var sockets = Sockets.Where(x => x != null);
            var strengthPoints = sockets.Sum(x => x.Strength);
            var agiltyPoints = sockets.Sum(x => x.Agility);
         
            return $"{Name}: {MinDamage+(strengthPoints*2+agiltyPoints)}-{MaxDamage+(strengthPoints*3+agiltyPoints*4)} Damage, +{strengthPoints} Strength, +{agiltyPoints} Agility, +{sockets.Sum(x=>x.Vitality)} Vitality";
        }
    }
}