﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using InfernoInfinity.Attributes;
using InfernoInfinity.Classes;
using InfernoInfinity.Enums;
using InfernoInfinity.Interfaces;

namespace InfernoInfinity
{
  
    public class Program
    {
        static void Main(string[] args)
        {IGemFactory gemFactory = new GemFactory();
           IWeaponFactory factory = new WeaponFactory();
            var weapons = new List<IWeapon>();
            var command = Console.ReadLine();
            var typep = typeof(Weapon);
            while (command!="END")
            {

                var parts = command.Split(";");
                var cmd = parts[0];
                switch (cmd)
                {
                    case "Create":
                        var type = parts[1].Split()[1];
                        var rarity = Enum.Parse<Rarity>(parts[1].Split()[0]);
                       var weapon= factory.CreateWeapon(type, parts[2], rarity);
                        weapons.Add(weapon);
                        break;
                    case "Add":
                        var gem = gemFactory.CreateGem(parts[3].Split()[1], Enum.Parse<Clarity>(parts[3].Split()[0]));
                        try
                        {
                            weapons.Find(x => x.Name == parts[1]).Sockets[int.Parse(parts[2])] = gem;
                        }
                        catch (Exception)
                        {
                            command = Console.ReadLine();

                            continue;

                        }

                        break;
                    case "Remove":
                        weapons.Find(x => x.Name == parts[1]).Sockets[int.Parse(parts[2])] = null;
                        break;
                    case "Print":
                        Console.WriteLine(weapons.Find(x=>x.Name==parts[1]));
                        break;
                    case "Author":
                        foreach (var customAttribute in typep.GetCustomAttributes())
                        {
                            if (customAttribute is CustomAttribute attr)
                            {
                                Console.WriteLine("Author: " + attr.Author);
                            }
                        }
                        break;
                    case "Description":
                        foreach (var customAttribute in typep.GetCustomAttributes())
                        {

                            if (customAttribute is CustomAttribute descattr)
                            {
                                Console.WriteLine("Class description: " + descattr.Description);
                            }
                        }
                        break;
                    case "Revision":
                        foreach (var customAttribute in typep.GetCustomAttributes())
                        {
                            if (customAttribute is CustomAttribute revattr)
                            {
                                Console.WriteLine("Revision: " + revattr.Revsion);
                            }

                        }
                        break;
                    case "Reviewers":
                        foreach (var customAttribute in typep.GetCustomAttributes())
                        {
                            if (customAttribute is CustomAttribute rewattr)
                            {
                                Console.WriteLine("Reviewers: " + String.Join(", ", rewattr.Reviewers));
                            }
                        }
                        break;
                }
                command = Console.ReadLine();
            }

        }
    }
}
