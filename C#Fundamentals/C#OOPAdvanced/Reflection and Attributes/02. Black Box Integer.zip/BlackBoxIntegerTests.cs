﻿using System.Reflection;

namespace P02_BlackBoxInteger
{
    using System;

    public class BlackBoxIntegerTests
    {
        public static void Main()
        {
        
            var newC = (BlackBoxInteger)Activator.CreateInstance(typeof(BlackBoxInteger),true);
            var cmd = Console.ReadLine();
            while (cmd!="END")
            {
                var parts = cmd.Split("_");
                var name = parts[0];
                var value = int.Parse(parts[1]);
                var method = typeof(BlackBoxInteger).GetMethod(name,BindingFlags.NonPublic|BindingFlags.Instance);

                method.Invoke(newC, new object[] { value});
                Console.WriteLine(typeof(BlackBoxInteger).GetField("innerValue",BindingFlags.NonPublic|BindingFlags.Instance).GetValue(newC));
                cmd = Console.ReadLine();
            }
        }
    }
}
