﻿ using System.Linq;
 using System.Reflection;

namespace P01_HarvestingFields
{
    using System;

    public class HarvestingFieldsTest
    {
        public static void Main()
        {
            var fieldClass = typeof(HarvestingFields);
            var command = Console.ReadLine();
            while (command!="HARVEST")
            {
                FieldInfo[] fields = null;
                switch (command)
                {
                    case "public":
                         fields = fieldClass.GetFields(BindingFlags.Public|BindingFlags.Instance);
                        break;
                    case "private":
                        fields = fieldClass.GetFields(BindingFlags.NonPublic | BindingFlags.Instance).Where(x=>x.IsPrivate).ToArray();
                        break;
                    case "protected":
                        fields = fieldClass.GetFields(BindingFlags.NonPublic | BindingFlags.Instance).Where(x=>x.IsFamily).ToArray();
                        break;
                    case "all":
                        fields = fieldClass.GetFields((BindingFlags)62);
                        break;
                }

                Array.ForEach(fields, x => Console.WriteLine($"{(x.IsPrivate?"private":x.IsFamily?"protected":"public")} {x.FieldType.Name} {x.Name}"));

                command = Console.ReadLine();
             }
        
        }
    }
}
