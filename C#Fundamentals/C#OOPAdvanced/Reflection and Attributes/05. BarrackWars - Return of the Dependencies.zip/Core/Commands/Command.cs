﻿using System.Windows.Input;
using _03BarracksFactory.Contracts;

namespace _03BarracksFactory.Core.Commands
{
    public abstract class Command:IExecutable
    {
        public string[] Data
        {
            get => data;
           private set => data = value;
        }

  

        private string[] data;
       
        protected Command(string[] data)
        {
            Data = data;
        
        }
        public abstract string Execute();



    }
}