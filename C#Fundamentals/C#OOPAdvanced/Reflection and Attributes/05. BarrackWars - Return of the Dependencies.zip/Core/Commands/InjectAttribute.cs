﻿using System;

namespace _03BarracksFactory.Core.Commands
{[AttributeUsage(AttributeTargets.Field,AllowMultiple = true,Inherited = false)]
    public class InjectAttribute:Attribute
    {
        public InjectAttribute()
        {
            
        }   
    }
}