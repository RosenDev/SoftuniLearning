﻿using _03BarracksFactory.Contracts;
using _03BarracksFactory.Data;

namespace _03BarracksFactory.Core.Commands
{
    
    public class Retire:Command
    {[Inject]
        private IRepository repository;
        public Retire(string[] data) : base(data)
        {
     
        }

        public override string Execute()
        {repository.RemoveUnit(Data[0]);
            return $"{Data[0]} retired!";
        }
    }
}