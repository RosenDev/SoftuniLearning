﻿using _03BarracksFactory.Contracts;
using _03BarracksFactory.Core.Factories;
using _03BarracksFactory.Data;

namespace _03BarracksFactory.Core.Commands
{
    public class Add:Command
    {[Inject]
        private IUnitFactory unitFactory;
        [Inject]
        private IRepository repository;
        public Add(string[] data) : base(data)
        {
   
        }


        public override string Execute()
        {
            string unitType = Data[0];
            IUnit unitToAdd = unitFactory.CreateUnit(unitType);
            repository.AddUnit(unitToAdd);
            string output = unitType + " added!";
            return output;
        }
    }
}