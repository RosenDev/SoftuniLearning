﻿using System;
using System.Linq;
using System.Reflection;
using _03BarracksFactory.Contracts;
using _03BarracksFactory.Core.Factories;
using _03BarracksFactory.Data;

namespace _03BarracksFactory.Core.Commands
{
    public class CommandInterpreter:ICommandInterpreter
    {
        private IUnitFactory unitFactory;
        private IRepository repository;
        public CommandInterpreter(IUnitFactory unitFactory, IRepository repository)
        {
            this.unitFactory = unitFactory;
            this.repository = repository;
        }
        public IExecutable InterpretCommand(string[] data, string commandName)
        {var attr= new InjectAttribute();

            var commandType = Assembly.GetCallingAssembly().GetTypes().FirstOrDefault(x => x.Name.ToLower() == commandName);
            var instance= (IExecutable)Activator.CreateInstance(commandType, new object[]{data});
            var fields = commandType.GetFields(BindingFlags.NonPublic | BindingFlags.Instance|BindingFlags.DeclaredOnly);
            foreach (var fieldInfo in fields)
            {
                if (fieldInfo.CustomAttributes.Any(x=>x.AttributeType==typeof(InjectAttribute)))
                {
                    if (fieldInfo.FieldType.Name == nameof(IRepository))
                    {
                        fieldInfo.SetValue(instance,repository);
                    }
                    else if (fieldInfo.FieldType.Name == nameof(IUnitFactory))
                    {
                        fieldInfo.SetValue(instance, unitFactory);
                    }

                }

            }
            return instance;
        }
    }
}