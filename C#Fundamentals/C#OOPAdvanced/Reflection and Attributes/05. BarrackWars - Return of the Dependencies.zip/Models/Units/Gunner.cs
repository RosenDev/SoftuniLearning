﻿namespace _03BarracksFactory.Models.Units
{
    public class Gunner:Unit
    {
        public Gunner() : base(20,20)
        {
        }
    }
}