﻿using System;

namespace Vehicles
{
   public class Program
    {
        static void Main(string[] args)
        {

            var carInfo = Console.ReadLine()?.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var truckInfo= Console.ReadLine()?.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var busInfo= Console.ReadLine()?.Split(" ", StringSplitOptions.RemoveEmptyEntries);
           IVehile car= new Car(double.Parse(carInfo?[1]),double.Parse(carInfo?[2]),double.Parse(carInfo?[3]));
            IVehile truck= new Truck(double.Parse(truckInfo?[1]), double.Parse(truckInfo?[2]),double.Parse(truckInfo?[3]));
           
            Vehicle bus = new Bus(double.Parse(busInfo?[1]),0, double.Parse(busInfo?[2]), double.Parse(busInfo?[3]));
            var lines = int.Parse(Console.ReadLine());
            
            for (int i = 0; i < lines; i++)
            {
                var command = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                var cmd = command[0];
                var type = command[1];
                var value =command[2];
                try
                {
                    if (nameof(car) == type.ToLower())
                    {
                        if (cmd == "Refuel")
                        {
                            car.Refuel(double.Parse(value));
                        }
                        else
                        {
                            car.Drive(double.Parse(value));
                        }
                    }
                    else if(nameof(truck)==type.ToLower())
                    {
                        if (cmd == "Refuel")
                        {
                            truck.Refuel(double.Parse(value));
                        }
                        else
                        {
                            truck.Drive(double.Parse(value));
                        }
                    }else if (nameof(bus)==type.ToLower())
                    {
                        if (cmd=="DriveEmpty")
                        {
                            bus.Drive(double.Parse(value));
                        }else if (cmd == "Refuel")
                        {
                            bus.Refuel(double.Parse(value));
                        }else if (cmd == "Drive")
                        {
                            bus.FuelConsumation = 1.4;
                            bus.Drive(double.Parse(value));

                        }
                    }
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
            Console.WriteLine($"Bus: {bus.FuelQuantity:f2}");
        }
    }
}
