﻿using System;

namespace Vehicles
{
    public class Truck:Vehicle
    {
        private  const double fuelConsumation = 1.6;

        public Truck(double fuelQuantity, double lttersPerKm,double capacity) : base(fuelQuantity, fuelConsumation,lttersPerKm,capacity)
        {
        }

        public sealed override void Refuel(double fuel)
        {
            base.Refuel(fuel);
            FuelQuantity += fuel * 0.95;

        }
    }
}