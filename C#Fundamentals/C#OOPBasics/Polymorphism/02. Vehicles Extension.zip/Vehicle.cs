﻿using System;

namespace Vehicles
{
    public  abstract class Vehicle: IVehile
    {
        private double fuelQuantity;
        private double fuelConsumation;
        private double litersPerKm;
        public double FuelQuantity { get => fuelQuantity;protected set => fuelQuantity=value>TankCapaity?0:value; }

        public double FuelConsumation
        {
            get => fuelConsumation;
            set => fuelConsumation = value <= 0 ? 0 : value;
        }
        public double LitersPerKm { get => litersPerKm;  set => litersPerKm =  value; }
        public double TankCapaity { get; }

        public void Drive(double distance)
        {
            if ((FuelConsumation + LitersPerKm) * distance <= FuelQuantity)
            {
                FuelQuantity -= (LitersPerKm + FuelConsumation) * distance;
                Console.WriteLine($"{GetType().Name} travelled {distance} km");
            }
            else
            {
 
                Console.WriteLine($"{GetType().Name} needs refueling");
            }
        }

        public Vehicle(double fuelQuantity,double fuelConsumation, double lttersPerKm,double tankCapaity)
        {
            TankCapaity = tankCapaity;
            this.FuelQuantity = fuelQuantity;
            FuelConsumation = fuelConsumation;
            this.LitersPerKm = lttersPerKm;
           
        }

        public virtual void Refuel(double fuel)
        {
            if (fuel<=0)
            {
                throw new ArgumentException("Fuel must be a positive number");
            }

            if (fuel+FuelQuantity>TankCapaity)
            {
                throw new ArgumentException($"Cannot fit {fuel} fuel in the tank");
            }
           
        }
    }
}