﻿namespace Vehicles
{
    public class Bus:Vehicle
    {

        public Bus(double fuelQuantity,double fuelConsumation,  double littersPerKm,double capacity) : base(fuelQuantity, fuelConsumation, littersPerKm,capacity)
        {
        }
    }
}