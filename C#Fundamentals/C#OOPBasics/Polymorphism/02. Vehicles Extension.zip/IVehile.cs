﻿namespace Vehicles
{
    public interface IVehile
    {
        double FuelQuantity { get; }
        double FuelConsumation { get; }
        double LitersPerKm { get; }
        double TankCapaity { get; }
        void Drive(double distance);
        void Refuel(double fuel);
    }
}