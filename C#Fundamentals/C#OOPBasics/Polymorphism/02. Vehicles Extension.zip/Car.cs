﻿using System;

namespace Vehicles
{
    public class Car:Vehicle
    {
        private const double fuelConsumation = 0.9;

        public Car(double fuelQuantity, double lttersPerKm,double capacity) : base(fuelQuantity, fuelConsumation, lttersPerKm,capacity)
        {
        }

        public override void Refuel(double fuel)
        {
            base.Refuel(fuel);
            FuelQuantity += fuel;
        }
    }
}