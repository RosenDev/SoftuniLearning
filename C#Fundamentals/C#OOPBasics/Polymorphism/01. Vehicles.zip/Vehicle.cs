﻿using System;

namespace Vehicles
{
    public  abstract class Vehicle: IVehile
    {
        private double fuelQuantity;
        private double fuelConsumation;
        private double litersPerKm;
        public double FuelQuantity { get => fuelQuantity; set => fuelQuantity = value < 0 ? throw new ArgumentException("Fuel Cannot be  <0") : value; }

        public double FuelConsumation
        {
            get => fuelConsumation;
          protected  set => fuelConsumation = value < 0 ? throw new ArgumentException("Fuel Cannot be  < 0") : value;
        }
        public double LitersPerKm { get => litersPerKm; set => litersPerKm = value < 0 ? throw new ArgumentException("Fuel Cannot be  <0") : value; }
        public void Drive(double distance)
        {
            if ((FuelConsumation + LitersPerKm) * distance <= FuelQuantity)
            {
                FuelQuantity -= (LitersPerKm + FuelConsumation) * distance;
                Console.WriteLine($"{GetType().Name} travelled {distance} km");
            }
            else
            {
                Console.WriteLine($"{GetType().Name} needs refueling");
            }
        }

        public Vehicle(double fuelQuantity,double fuelConsumation, double lttersPerKm)
        {
            this.FuelQuantity = fuelQuantity;
            FuelConsumation = fuelConsumation;
            this.LitersPerKm = lttersPerKm;
        }

        public virtual void Refuel(double fuel)
        {
            FuelQuantity += fuel;
        }
    }
}