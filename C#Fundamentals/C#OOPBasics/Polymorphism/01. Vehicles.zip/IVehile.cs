﻿namespace Vehicles
{
    public interface IVehile
    {
        double FuelQuantity { get; }
        double FuelConsumation { get; }
        double LitersPerKm { get; }

        void Drive(double distance);
        void Refuel(double fuel);
    }
}