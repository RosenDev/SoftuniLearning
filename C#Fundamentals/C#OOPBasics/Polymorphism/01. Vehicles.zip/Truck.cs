﻿using System;

namespace Vehicles
{
    public class Truck:Vehicle
    {
        private  const double fuelConsumation = 1.6;

        public Truck(double fuelQuantity, double lttersPerKm) : base(fuelQuantity, fuelConsumation,lttersPerKm)
        {
        }

        public sealed override void Refuel(double fuel)
        {
            FuelQuantity += fuel * 0.95;
        }
    }
}