﻿using System;

namespace Vehicles
{
    public class Car:Vehicle
    {
        private const double fuelConsumation = 0.9;

        public Car(double fuelQuantity, double lttersPerKm) : base(fuelQuantity, fuelConsumation, lttersPerKm)
        {
        }
        
    }
}