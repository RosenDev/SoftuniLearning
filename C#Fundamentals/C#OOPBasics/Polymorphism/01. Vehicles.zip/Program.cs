﻿using System;

namespace Vehicles
{
   public class Program
    {
        static void Main(string[] args)
        {

            var carInfo = Console.ReadLine()?.Split(" ", StringSplitOptions.RemoveEmptyEntries);
            var truckInfo= Console.ReadLine()?.Split(" ", StringSplitOptions.RemoveEmptyEntries);
           IVehile car= new Car(double.Parse(carInfo?[1]),double.Parse(carInfo?[2]));
            IVehile truck= new Truck(double.Parse(truckInfo?[1]), double.Parse(truckInfo?[2]));
            var lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                var command = Console.ReadLine().Split(" ", StringSplitOptions.RemoveEmptyEntries);
                var cmd = command[0];
                var type = command[1];
                var distance =command[2];
                if (nameof(car) == type.ToLower())
                {
                    if (cmd=="Refuel")
                    {
                        car.Refuel(double.Parse(distance));
                    }
                    else
                    {
                        car.Drive(double.Parse(distance));
                    }
                }
                else
                {
                    if (cmd == "Refuel")
                    {
                        truck.Refuel(double.Parse(distance));
                    }
                    else
                    {
                        truck.Drive(double.Parse(distance));
                    }
                }
            }

            Console.WriteLine($"Car: {car.FuelQuantity:f2}");
            Console.WriteLine($"Truck: {truck.FuelQuantity:f2}");
        }
    }
}
