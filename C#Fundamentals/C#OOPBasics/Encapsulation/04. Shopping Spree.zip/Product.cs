﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EncapsulationExercise
{
    class Product
    {
        private string name;
        private int price;

        public string Name
        {
         get => name;
          private  set
            {
                if (string.IsNullOrEmpty(value) || value == " ")
                {
                    throw new ArgumentException("Name cannot be empty");
                }
                else
                {
                    name = value;
                }
                
            }
        }

        public Product(string name, int price)
        {
            Name = name;
            Price = price;
        }

        public override string ToString()
        {
            return Name;
        }

        public int Price
        {
            get => price;
          private  set
            {
                if (value<0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }
                else
                {
                    price = value;
                }
            }
        }
    }
}
