﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace EncapsulationExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            var persons = new List<Person>();
            var products = new List<Product>();
            var pInput = Console.ReadLine();
            var p2Iput = Console.ReadLine();
            if (!pInput.Contains(";"))
            {
                try
                {
                    persons.Add(new Person(pInput.Split("=")[0], int.Parse(pInput.Split("=")[1])));
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
               
            }
            else
            {
                try
                {
                    var personInput = pInput.Trim().Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();



                    personInput.ForEach(x => persons.Add(new Person(x.Split("=")[0], int.Parse(x.Split("=")[1]))));

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }

            if (!p2Iput.Contains(";"))
            {
                
                try
                {
                    products.Add(new Product(p2Iput.Split("=")[0], int.Parse(p2Iput.Split("=")[1])));

                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }
            else
            {
                try
                {
                    var productInput = p2Iput.Trim().Split(";", StringSplitOptions.RemoveEmptyEntries).ToList();
                    productInput.ForEach(x => products.Add(new Product(x.Split("=")[0], int.Parse(x.Split("=")[1]))));
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    return;
                }
            }
            
               
            
            var input = Console.ReadLine();
            while (input!="END")
            {
                var person = input.Split()[0];
                var product = input.Split()[1];
               var personA=persons[persons.IndexOf(persons.Find(x => x.Name == person))].Buy(products.Find(x=>x.Name==product));
                var index = persons.IndexOf(persons.Find(x => x.Name == person));
                persons.RemoveAt(index);
                persons.Insert(index,personA);
                input = Console.ReadLine();
            }

           persons.ForEach(x=>
           {
               if (x.Products.Count!=0)
               {
                   Console.WriteLine($"{x.Name} - {string.Join(", ",x.Products)}");
               }
               else
               {
                   Console.WriteLine($"{x.Name} - Nothing bought");
               }
               
           });
            
        }
    }
}
