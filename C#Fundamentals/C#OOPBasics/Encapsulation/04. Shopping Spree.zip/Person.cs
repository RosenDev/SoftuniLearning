﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EncapsulationExercise
{
    class Person
    {
        private string name;
        private int money;
        private List<Product> products;

        public Person(string name, int money)
        {
            Name = name;
            Money = money;
            Products=new List<Product>();

        }

        public List<Product> Products { get=>products;  set=>products=value; }
        public int Money
        {
            get => money;
            set
            {
                if (value<0)
                {
                    throw new ArgumentException("Money cannot be negative");
                }
                else
                {
                    money = value;
                }
            }
        }

        public Person Buy(Product product)
        
        {
            if (Money>=product.Price)
            {
                Products.Add(product);
                Money -= product.Price;
                Console.WriteLine($"{Name} bought {product.Name}");
            }
            else
            {
                Console.WriteLine($"{Name} can't afford {product.Name}");
            }

            return this;
        }
        public string Name
        {
            get => name;
            private set
            {
                if (string.IsNullOrEmpty(value) || value == " ")
                {
                    throw new ArgumentException("Name cannot be empty");
                }
                else
                {
                    name = value;
                }

            }
        }

    }
}
