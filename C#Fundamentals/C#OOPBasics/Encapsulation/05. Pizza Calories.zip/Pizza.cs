﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EncapsulationExercise
{
    class Pizza
    {
        private List<Topping> toppings;
        private Dough dough;
        private string name;
     
        public Pizza(string name)
        {
            Name = name;
            toppings= new List<Topping>();
        }

        public void Add(Topping value)
        {
            if (toppings.Count==9)
            {
                throw new ArgumentException("Number of toppings should be in range [0..10].");
            }
            else
            {
                toppings.Add(value);
            }

        }

        public decimal GetValue()
        {
            return toppings.Sum(x => x.GetCalories()) + dough.GetCalories();
        }
        public override string ToString()
        {
            return $"{Name} - {GetValue():f2} Calories.";
        }

        public string Name
        {
            get => name;
            set
            {
                if (string.IsNullOrEmpty(value)||value.Length>15)
                {
                    throw new ArgumentException("Pizza name should be between 1 and 15 symbols.");
                }
                name = value;
            }
        }
        public Dough Dough
        {
            get => dough;
            set => dough = value;




        }
    }
}
