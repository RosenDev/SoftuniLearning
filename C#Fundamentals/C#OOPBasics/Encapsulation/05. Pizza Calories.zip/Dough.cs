﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace EncapsulationExercise
{
    class Dough
    {
        private string flavourType;
        private string bakingTechnique;
        private int weight;

        public int Weight
        {
            get => weight;
            set
            {
                if (value<1||value>200)
                {
                    throw new ArgumentException("Dough weight should be in the range [1..200].");
                }

                weight = value;
            }
        }

        public Dough(string flavourType, string bakingTechnique,int weight)
        {
            FlavourType = flavourType;
            BakingTechnique = bakingTechnique;
            Weight = weight;
        }

        public string FlavourType
        {
            get => flavourType;
            set
            {
                if (value.ToLower()!="white"&&value.ToLower()!="wholegrain")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }
                else
                {
                    flavourType = value;
                }
            }
        }

        public string BakingTechnique
        {
            get => bakingTechnique;
            set
            {
                if (value.ToLower()!="chewy"&&value.ToLower()!="crispy"&&value.ToLower()!="homemade")
                {
                    throw new ArgumentException("Invalid type of dough.");
                }
                else
                {
                    bakingTechnique = value;
                }
            }
        }

        public decimal GetCalories()
        {
            var calories = 2m * weight;
            switch (FlavourType.ToLower())
            {
                case "white":
                    calories *= 1.5m;
                break;
                case "wholegrain":
                    calories *= 1m;
                    break;

            }

            switch (BakingTechnique.ToLower())
            {
                case "crispy":
                    calories *= 0.9m;
                    break;
                case "chewy":
                    calories *= 1.1m;

                    break;
                case "homemade":
                    calories *= 1m;
                    break;
            }

            return calories;
        }

        public override string ToString()
        {
            return $"{this.GetCalories():f2}";
        }
    }
}
