﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EncapsulationExercise
{
    class Topping
    {
        private int weight;
        private string topping;
        public Topping(string type, int weight)
        {
            Type = type;
            Weight = weight;
        }

        public override string ToString()
        {
            return $"{GetCalories():f2}";
        }

        public decimal GetCalories()
        {
            var calories = 2m * Weight;
         calories*=   Type.ToLower() == "meat" ? 1.2m :
                Type.ToLower() == "veggies" ?0.8m :
                Type.ToLower() == "cheese" ? 1.1m :
                Type.ToLower() == "sauce" ? 0.9m:1m;
            return calories;
        }
        public string Type
        {
            get => topping;
            set
            {
                if (value.ToLower()!="meat"&& value.ToLower()!="veggies"&&value.ToLower()!="cheese"&&value.ToLower()!="sauce")
                {
                    throw new ArgumentException($"Cannot place {value} on top of your pizza.");
                }

             topping = value;
            }
        }

        

        public int Weight
        {
            get=>weight;
            set
            {
                if (value<1||value>50)
                {
                    throw new ArgumentException($"{Type} weight should be in the range [1..50].");


                }

                weight = value;
            }
        }

    }
}
