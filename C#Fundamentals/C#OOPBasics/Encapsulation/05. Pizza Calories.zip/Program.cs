﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace EncapsulationExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            Pizza piza;
            var name = Console.ReadLine().Split()[1];
            try
            {
                piza=new Pizza(name);
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                return;
            }
            var inut = Console.ReadLine();
            while (inut!="END")
            {
                var info = inut.Split(" ");
                if (info[0]=="Dough")
                {
                    try
                    {
                        var dough = new Dough(info[1], info[2], int.Parse(info[3]));
                        piza.Dough = dough;
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                        return;
                    }
                    
                }
                else
                {
                    try
                    {
                        var topping = new Topping(info[1], int.Parse(info[2]));
                        piza.Add(topping);
                        
                    }
                    catch (ArgumentException e)
                    {
                        Console.WriteLine(e.Message);
                        return;
                    }
                }

                inut = Console.ReadLine();
            }

            Console.WriteLine(piza);
        }
    }
}
