﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace EncapsulationExercise
{
    class Player
    {
        private string name;
        private int endurance;
        private int sprint;
        private int dribble;
        private int passing;
        private int shoot;
        private int level;

        public int Level
        {
            get => level;
            set => level = value;
        }

        public string Name
        {
            get => name;
        set
        {
            if (string.IsNullOrEmpty(value)||value==" ")
            {
                throw new ArgumentException("A name should not be empty.");
            }

            name = value;
        }
        }

        public int Endurance
        {
            get => endurance;
            set
            {
                if (value<0||value>100)
                {
                    throw new ArgumentException($"Endurance should be between 0 and 100.");
                }

                endurance = value;
            }
        }

        public int Sprint
        {
            get => sprint;
            set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentException($"Sprint should be between 0 and 100.");
                }

                sprint = value;
            }
        }

        public int Dribble
        {
            get => dribble;
            set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentException($"Dribble should be between 0 and 100.");
                }

               dribble = value;
            }
        }

        public int Passing
        {
            get => passing;
            set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentException($"Passing should be between 0 and 100.");
                }

               passing = value;
            }
        }

        public Player(string name, int endurance, int sprint, int dribble, int passing, int shoot)
        {
            this.Name = name;
            this.Endurance = endurance;
            this.Sprint = sprint;
            this.Dribble = dribble;
            this.Passing = passing;
            this.Shoot = shoot;
            var list = new List<int>{endurance,sprint,dribble,passing,shoot};
            level = (int) Math.Round(list.Average());
        }

        public int Shoot
        {
            get => shoot;
            set
            {
                if (value < 0 || value > 100)
                {
                    throw new ArgumentException($"Shoot should be between 0 and 100.");
                }

                shoot = value;
            }
        }
    }
}
