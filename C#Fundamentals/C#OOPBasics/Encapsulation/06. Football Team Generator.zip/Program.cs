﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;

namespace EncapsulationExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            var teams= new List<Team>();
            var input = Console.ReadLine();
            while (input!="END")
            {
                var cmd= input.Split(";");
                try
                {
                    switch (cmd[0])
                    {
                        case "Team":
                            var name = cmd[1];
                            teams.Add(new Team(name));
                            break;
                        case "Add":
                            var teamName = cmd[1];
                            var playerName = cmd[2];
                            var endurance = int.Parse(cmd[3]);
                            var sprint = int.Parse(cmd[4]);
                            var dribble = int.Parse(cmd[5]);
                            var passing = int.Parse(cmd[6]);
                            var shooting = int.Parse(cmd[7]);
                            if (!teams.Exists(x=>x.Name==teamName))
                            {
                                throw new ArgumentException($"Team {teamName} does not exist.");
                            }
                            teams[teams.IndexOf(teams.Find(x=>x.Name==teamName))].AddPlayer(new Player(playerName,endurance,sprint,dribble,passing,shooting));
                            break;
                        case "Remove":
                            teams[teams.IndexOf(teams.Find(x=>x.Name==cmd[1]))].RemovePayer(cmd[2]);
                            break;
                        case "Rating":
                            if (!teams.Exists(x=>x.Name==cmd[1]))
                            {
                                throw new ArgumentException($"Team {cmd[1]} does not exist.");
                            }

                            Console.WriteLine($"{cmd[1]} - {teams.Find(x=>x.Name==cmd[1]).GetRating()}");
                            break;

                    }
                }
                catch (ArgumentException e)
                {
                    Console.WriteLine(e.Message);
                    input = Console.ReadLine();
                    continue;
                }

                

                input = Console.ReadLine();
            }

        }
    }
}
