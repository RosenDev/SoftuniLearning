﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;

namespace EncapsulationExercise
{
    class Team
    {
        private List<Player> players;
        private string name;
      

        public string Name
        {
            get => name;
          private set
          {
              if (string.IsNullOrEmpty(value) || value == " ")
              {
                  throw new ArgumentException("A name should not be empty.");
              }

              name = value;
          }
        }


        public int GetRating()
        {
            if (players.Count==0)
            {
                return 0;
            }
            return (int) Math.Round(players.Average(x => x.Level));
        }
        public Team(string name)
        {
            this.Name = name;
            
            players= new List<Player>();
        }

        public void AddPlayer(Player p)
        {
            players.Add(p);
        }

        public void RemovePayer(string name)
        {
            if (!players.Exists(x=>x.Name==name))
            {
                throw new ArgumentException($"Player {name} is not in {this.Name} team.");
            }
            players.RemoveAll(x => x.Name == name);
        }
    }
}
