﻿using System;

namespace EncapsulationExercise
{
    class Program
    {
        static void Main(string[] args)
        {
            var length = double.Parse(Console.ReadLine());
            var weight = double.Parse(Console.ReadLine());
            var height = double.Parse(Console.ReadLine());
            try
            {
                var box = new Box(length, height, weight);

                Console.WriteLine($"Surface Area - {box.GetSurface():f2}");
                Console.WriteLine($"Lateral Surface Area - {box.GetLateralSurface():f2}");
                Console.WriteLine($"Volume - {box.GetVolume():f2}");
            }
            catch (ArgumentException e)
            {
                Console.WriteLine(e.Message);
                
            }
           
        }
    }
}
