﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EncapsulationExercise
{
    class Box
    {
        private double length;
        private double height;
        private double weight;

        public double Length
        {
            get => length;
            private set
            {
                if (value<=0)
                {
                    throw  new ArgumentException("");
                }
                else
                {
                    length = value;
                }
            }
        }

        public double Height
        {
            get => height;
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("");
                }
                else
                {
                    height = value;
                }
            }
        }

        public double Weight
        {
            get => weight;
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException("");
                }
                else
                {
                    weight = value;
                }
            }
        }

        public double GetSurface()=>2*(Length*Height)+2*(Length*Weight)+2*(Weight*Height);
        public double GetLateralSurface()=>2*(Length*Height)+2*(Weight*Height);
        public double GetVolume()=>Length*Weight*Height;
        public Box(double length, double height, double weight)
        {
            Length = length;
            Height = height;
            Weight = weight;
        }
    }
}
