﻿using System;
using System.Collections.Generic;
using System.Text;
using Car.Enums;
using Car.Interfaces;

namespace Car.Classes
{
    class Engineer:SpecialisedSoldier,IEngineer
    {
        public ICollection<IRepair> Repairs { get;}
        public override string ToString()
        {
            if (Repairs.Count==0)
            {
                return base.ToString() + $"\nRepairs:{string.Join("\n", Repairs)}";
            }
            return base.ToString()+$"\nRepairs:\n{string.Join("\n",Repairs)}";
        }

        public Engineer(int id, string firstName, string lastName, decimal salary, Corps corp,ICollection<IRepair>repairs) : base(id, firstName, lastName, salary, corp)
        {
            Repairs = repairs;
        }
    }
}
