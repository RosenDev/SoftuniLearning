﻿using System.Collections.Generic;
using Car.Enums;
using Car.Interfaces;

namespace Car.Classes
{
    public class Commando:SpecialisedSoldier,ICommando
    {
        public ICollection<IMission> Missions { get;}
        public override string ToString()
        {
            if (Missions.Count==0)
            {
                return base.ToString() + $"\nMissions:{string.Join("\n", Missions)}";
            }
            
            return base.ToString()+$"\nMissions:\n{string.Join("\n",Missions)}";
        }

        public Commando(int id, string firstName, string lastName, decimal salary, Corps corp,ICollection<IMission>missions) : base(id, firstName, lastName, salary, corp)
        {
            Missions = missions;
        }
    }
}