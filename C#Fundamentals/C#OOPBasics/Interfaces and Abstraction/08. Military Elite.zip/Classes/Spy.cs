﻿using Car.Interfaces;

namespace Car.Classes
{
    public class Spy:Soldier,ISpy
    {
        public int CodeNumber { get;}

        public override string ToString()
        {
            return base.ToString()+$"\nCode Number: {CodeNumber}";
        }

        public Spy(int id, string firstName, string lastName,int codeNumber) : base(id, firstName, lastName)
        {
            CodeNumber = codeNumber;
        }
    }
}