﻿using System.Collections.Generic;
using Car.Interfaces;

namespace Car.Classes
{
    public class LieutenantGeneral:Private,ILieutenantGeneral
    {
        public ICollection<IPrivate> Privates { get;}
        public override string ToString()
        {
            if (Privates.Count==0)
            {
                return base.ToString() + $"\nPrivates:{string.Join("\n", Privates)}";
            }
            return base.ToString()+$"\nPrivates:\n {string.Join("\n ",Privates)}";
        }

        public LieutenantGeneral(int id, string firstName, string lastName, decimal salary,ICollection<IPrivate>privates) : base(id, firstName, lastName, salary)
        {
            Privates = privates;
        }
    }
}