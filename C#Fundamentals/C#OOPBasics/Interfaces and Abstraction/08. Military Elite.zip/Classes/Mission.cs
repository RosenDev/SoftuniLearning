﻿using System;
using System.Collections.Generic;
using System.Text;
using Car.Enums;
using Car.Interfaces;

namespace Car.Classes
{
    class Mission:IMission
    {
        public Mission(string codeName, State state)
        {
            CodeName = codeName;
            State = state;
        }

        public override string ToString()
        {
            return $" Code Name: {CodeName} State: {State}";
        }

        public string CodeName { get; }
        public State State { get; private set; }
        public void CompleteMission()
        {
            this.State = State.Finished;
        }
    }
}
