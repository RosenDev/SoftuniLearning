﻿using System;
using System.Collections.Generic;
using System.Text;
using Car.Enums;
using Car.Interfaces;

namespace Car.Classes
{
    public class SpecialisedSoldier:Private,ISpecialisedSoldier
    {
        public Corps Corps { get;}
        public ICollection<IRepair> Repairs { get; }

        public override string ToString()
        {
            return base.ToString()+$"\nCorps: {Corps}";
        }

        public SpecialisedSoldier(int id, string firstName, string lastName, decimal salary,Corps corp) : base(id, firstName, lastName, salary)
        {
            Corps = corp;
        }
    }
}
