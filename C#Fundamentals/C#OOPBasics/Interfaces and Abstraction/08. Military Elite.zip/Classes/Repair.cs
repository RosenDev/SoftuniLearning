﻿using Car.Interfaces;

namespace Car.Classes
{
    public class Repair:IRepair
    {
        public Repair(string partName, int hoursWorked)
        {
            PartName = partName;
            HoursWorked = hoursWorked;
        }

        public override string ToString()
        {
            return $" Part Name: {PartName} Hours Worked: {HoursWorked}";
        }

        public string PartName { get; }
        public int HoursWorked { get; }
    }
}