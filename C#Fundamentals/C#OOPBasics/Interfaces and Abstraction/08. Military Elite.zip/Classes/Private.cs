﻿using Car.Interfaces;

namespace Car.Classes
{
    public class Private:Soldier,IPrivate

    {
        public override string ToString()
        {
            return base.ToString()+$" Salary: {Salary:f2}";
        }
        public decimal Salary { get; }

        public Private(int id, string firstName, string lastName,decimal salary) : base(id, firstName, lastName)
        {
            Salary = salary;
        }
    }
}