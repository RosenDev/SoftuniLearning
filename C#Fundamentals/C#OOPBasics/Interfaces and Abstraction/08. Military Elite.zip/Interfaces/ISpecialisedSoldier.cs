﻿using System.Collections.Generic;
using Car.Enums;

namespace Car.Interfaces
{
    public interface ISpecialisedSoldier:IPrivate
    {
        Corps Corps { get; }
        ICollection<IRepair> Repairs { get; }
    }
}