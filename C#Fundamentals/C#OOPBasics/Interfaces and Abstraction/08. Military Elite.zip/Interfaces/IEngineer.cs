﻿using System.Collections;
using System.Collections.Generic;

namespace Car.Interfaces
{
    public interface IEngineer:ISpecialisedSoldier
    {
        ICollection<IRepair> Repairs { get; }
    }
}