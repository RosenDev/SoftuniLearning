﻿using System.Collections;
using System.Collections.Generic;

namespace Car.Interfaces
{
    public interface ILieutenantGeneral:IPrivate
    {
       ICollection<IPrivate> Privates { get; }
            
    }
}