﻿namespace Car.Interfaces
{
    public interface IPrivate:ISoldier
    {
        decimal Salary { get; }
    }
}