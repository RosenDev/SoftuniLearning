﻿using System.Collections;
using System.Collections.Generic;

namespace Car.Interfaces
{
    public interface ICommando:ISpecialisedSoldier
    {
      ICollection<IMission> Missions { get; }
       
    }
}