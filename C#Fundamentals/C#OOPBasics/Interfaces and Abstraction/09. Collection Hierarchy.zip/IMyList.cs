﻿using System.Collections.Generic;

namespace CollectionHeraerrchy
{
    public interface IMyList<T> : IAddRemoveCollection<T>
    {
        IReadOnlyCollection<T> Used { get; }
    }
}