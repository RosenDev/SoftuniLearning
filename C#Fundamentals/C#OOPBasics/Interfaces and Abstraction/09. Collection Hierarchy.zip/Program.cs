﻿namespace CollectionHeraerrchy
{
    public class Program
    {
        static void Main(string[] args)
        {
            Engine e = new Engine();
            e.Run();
        }
    }
}