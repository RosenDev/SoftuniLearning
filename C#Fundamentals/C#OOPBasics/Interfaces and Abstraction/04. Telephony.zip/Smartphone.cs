﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace Car
{
    public class Smartphone:ISmartphone
    {
        private List<string> phones;
        private List<string> sites;

        public Smartphone(List<string> phones, List<string> sites)
        {
            this.phones = phones;
            this.sites = sites;
        }

        public void Call()
        {
            foreach (var phone in phones)
            {
                if (phone.Any(x=>char.IsLetter(x)))
                {
                    Console.WriteLine($"Invalid number!");
                    continue;
                }
                Console.WriteLine($"Calling... {phone}");
            }
        }

        public void Browse()
        {
            foreach (var site in sites)
            {
                if (site.Any(x=>char.IsDigit(x)))
                {
                    Console.WriteLine($"Invalid URL!");
                    continue;
                }
                Console.WriteLine($"Browsing: {site}!");
            }
        }
    }
}