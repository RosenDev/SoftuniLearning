﻿namespace Car
{
    public interface IBrowseable
    {
        void Browse();
    }
}