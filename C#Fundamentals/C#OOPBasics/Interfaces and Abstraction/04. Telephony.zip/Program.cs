﻿using System;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace Car
{
    public class Program
    {
        static void Main(string[] args)
        {
           ISmartphone smart = new Smartphone(Console.ReadLine().Split().ToList(),Console.ReadLine().Split().ToList());
            smart.Call();
            smart.Browse();

        }
    }
}