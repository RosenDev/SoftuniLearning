﻿namespace Car
{
    public interface ICallable
    {
        void Call();
    }
}