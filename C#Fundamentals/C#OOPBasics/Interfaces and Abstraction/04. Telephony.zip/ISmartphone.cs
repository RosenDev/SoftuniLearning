﻿namespace Car
{
    public interface ISmartphone:ICallable,IBrowseable
    {
        
    }
}