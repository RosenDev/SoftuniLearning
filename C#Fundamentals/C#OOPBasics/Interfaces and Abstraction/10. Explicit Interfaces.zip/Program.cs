﻿using System;
using System.Collections;
using System.Collections.Generic;

namespace CollectionHeraerrchy
{
   public class Program
    {
        static void Main(string[] args)
        {ICollection<Citizen> coll= new List<Citizen>();
            var input = Console.ReadLine();
            while (input!="End")
            {
                var info = input.Split();
                coll.Add(new Citizen(info[0],info[1],int.Parse(info[2])));
                input = Console.ReadLine();
            }
            foreach (var citizen in coll)
            {
                Console.WriteLine(citizen.GetName());
                IResident cit = citizen;
                Console.WriteLine(cit.GetName());
            }
        }
    }
}
