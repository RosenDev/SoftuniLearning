﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace Car
{
    public class Program
    {
        static void Main(string[] args)
        {
            var info = new List<IIdable>();
            var input = Console.ReadLine();
            while (input!="End")
            {
                var arg = input.Split();
                if (arg.Length==3)
                {
                  info.Add(new Citizen(arg[2]));  
                }
                else
                {
                 info.Add(new Robot(arg[1]));   
                }
                input = Console.ReadLine();
            }

            var vallidation = Console.ReadLine();
            foreach (var idable in info)
            {
                if (idable.IsValid(vallidation))
                {
                    Console.WriteLine(idable.Id);
                }
            }
        }
    }
}