﻿using System.Linq;

namespace Car
{
    public class Robot:IIdable
    {
        public Robot(string id)
        {
            Id = id;
        }

        public string Id { get; }
        public bool IsValid(string validation)
        {
            return Id.EndsWith(validation);


        }
    }
}