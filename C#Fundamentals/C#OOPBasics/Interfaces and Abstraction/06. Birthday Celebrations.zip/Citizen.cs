﻿using System;
using System.Linq;

namespace Car
{
    public class Citizen:IIdable,IBirthale
    {
        public Citizen(string id,DateTime birthdate)
        {
            Id = id;
            Birthdate = birthdate;
        }

        public string Id { get; }
        public bool IsValid(string validation)
        {
            return Id.EndsWith(validation);

        }

        public DateTime Birthdate { get; }
    }
}