﻿using System;

namespace Car
{
    public class Pet:IBirthale
    {
        public DateTime Birthdate { get; }

        public Pet(DateTime birthdate)
        {
            Birthdate = birthdate;
        }
    }
}