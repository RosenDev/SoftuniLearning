﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;

namespace Car
{
    public class Program
    {
        static void Main(string[] args)
        {
            var info = new List<IBirthale>();
            var input = Console.ReadLine();
            while (input != "End")
            {
                var arg = input.Split();
                if (arg.Length == 5)
                {
                    info.Add(new Citizen(arg[1],
                        DateTime.ParseExact(arg[4], "dd/MM/yyyy", CultureInfo.InvariantCulture)));
                }
                else if (arg[0] == "Pet")
                {


                    {
                        info.Add(new Pet(DateTime.ParseExact(arg[2], "dd/MM/yyyy", CultureInfo.InvariantCulture)));
                    }
                    
                }
                input = Console.ReadLine();
            }

            var vallidation = Console.ReadLine();
                foreach (var idable in info)
                {
                    if (idable.Birthdate.Year.ToString() == vallidation)
                    {
                        Console.WriteLine($"{idable.Birthdate.Day:d2}/{idable.Birthdate.Month:d2}/{idable.Birthdate.Year}");
                    }
                }
            
        }
    }
}