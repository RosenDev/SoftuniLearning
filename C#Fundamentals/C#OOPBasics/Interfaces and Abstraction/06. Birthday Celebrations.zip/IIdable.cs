﻿namespace Car
{
    public interface IIdable
    {
        string Id
        {
            get;
        
        }

        bool IsValid(string validdation);
    }
}