﻿using System;

namespace Car
{
    public interface IBirthale
    {
        DateTime Birthdate { get; }
        
    }
}