﻿using System;

namespace Car
{
    public class Rebel:IBuyer
    {
        private string name;

        public Rebel(string name, int age, string group)
        {
            this.name = name;
            Age = age;
            Group = group;
        }

        public string Name
        {
            get => name;
          private  set
            {
                
               
                    name = value;
                

              
            }
        }
        public int Age { get; private set; }
        public string Group { get; private set; }
        public int ItemsBought { get; private set; }
        public void Buy()
        {

            ItemsBought += 5;
        }
    }
}