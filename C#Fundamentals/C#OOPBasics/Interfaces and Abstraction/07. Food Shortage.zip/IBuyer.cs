﻿namespace Car
{
    public interface IBuyer
    {
        int ItemsBought
        {
            get;

        }
        string Name { get; }
        void Buy();
    }
}