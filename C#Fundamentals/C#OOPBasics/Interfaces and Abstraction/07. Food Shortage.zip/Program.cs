﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Security.Cryptography.X509Certificates;

namespace Car
{
    public class Program
    {
        static void Main(string[] args)
        {
            var buyers= new List<IBuyer>();
          
            var lines = Console.ReadLine();
            for (int i = 0; i < int.Parse(lines); i++)
            {
                var arg = Console.ReadLine();
                var info = arg.Split();
                if (info.Length == 4)
                {
                    if (!buyers.Exists(x => x.Name == info[0]))
                    {
                        buyers.Add(new Citizen(info[0], info[2],
                            DateTime.ParseExact(info[3], "dd/MM/yyyy", CultureInfo.InvariantCulture)));
                    }

                }
                else if (info.Length == 3)
                {
                    if (!buyers.Exists(x => x.Name == info[0]))
                    {
                        buyers.Add(new Rebel(info[0], 0, ""));
                    }
                }
            }

            var input = Console.ReadLine();
            while (input!="End")
            {

                if (buyers.Exists(x=>x.Name==input))
                {
                buyers[buyers.IndexOf(buyers.Find(x=>x.Name==input))].Buy();
                }
                input = Console.ReadLine();
                }
                
            

            Console.WriteLine(buyers.Sum(x=>x.ItemsBought));
        }
    }
}