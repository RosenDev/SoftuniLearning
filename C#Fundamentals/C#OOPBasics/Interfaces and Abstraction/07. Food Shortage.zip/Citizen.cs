﻿using System;
using System.Linq;

namespace Car
{
    public class Citizen:IBuyer
    {
        private string name;
        public Citizen(string name,string id,DateTime birthdate)
        {
            Name = name;
            Id = id;
            Birthdate = birthdate;
        }

        public string Name
        {
            get => name;
            private set
            {
                if (name!=value)
                {
                    name = value;
                }
               
            }
        }

        public string Id { get; }
        public bool IsValid(string validation)
        {
            return Id.EndsWith(validation);

        }
        
        public DateTime Birthdate { get; }
        public int ItemsBought { get; private set; }
        public void Buy()
        {
            ItemsBought += 10;
        }
    }
}