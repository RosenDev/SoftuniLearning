﻿namespace Car
{
    public interface IFerrari
    {
        string driver { get; }
        string Brakes();
        string GasPedal();
    }
}