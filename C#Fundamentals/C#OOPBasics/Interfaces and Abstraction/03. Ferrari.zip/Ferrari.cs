﻿namespace Car
{
    public class Ferrari:IFerrari
    {
        public Ferrari(string driver)
        {
            this.driver = driver;
        }

        public override string ToString()
        {
            return $"488-Spider/{Brakes()}/{GasPedal()}/{driver}";
        }

        public string driver { get; }
        public string Brakes()
        {
            return "Brakes!";
        }

        public string GasPedal()
        {
            return "Zadu6avam sA!";
        }
    }
}