﻿using System;

namespace Car
{
    class Program
    {
        static void Main(string[] args)
        {
            IFerrari ferrari = new Ferrari(Console.ReadLine());
            Console.WriteLine(ferrari);
        }
    }
}
