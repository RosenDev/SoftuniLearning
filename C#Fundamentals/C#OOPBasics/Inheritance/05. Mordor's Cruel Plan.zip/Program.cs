﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceExercise
{
   public class Program
    {
        static void Main(string[] args)
        {
            var value = 0;
            var foods = Console.ReadLine().Split();
            foreach (var food in foods)
            {
                value += FoodFactory.CreateFood(food).Points;
            }

            Console.WriteLine(value);
            Console.WriteLine(MoodFactory.CreateMood(value).Value);
        }
    }
}
