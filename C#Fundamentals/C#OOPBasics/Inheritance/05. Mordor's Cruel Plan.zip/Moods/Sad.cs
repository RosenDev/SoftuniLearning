﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Moods
{
    class Sad:Mood
    {
        public override string Value { get=>"Sad"; }
    }
}
