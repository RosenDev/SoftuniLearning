﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Moods
{
    class Angry:Mood
    {
        public override string Value { get=>"Angry"; }
    }
}
