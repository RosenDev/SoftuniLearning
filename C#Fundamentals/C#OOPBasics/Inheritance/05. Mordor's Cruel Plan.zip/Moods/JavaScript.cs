﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Moods
{
    class JavaScript:Mood
    {
        public override string Value { get=>"JavaScript"; }
    }
}
