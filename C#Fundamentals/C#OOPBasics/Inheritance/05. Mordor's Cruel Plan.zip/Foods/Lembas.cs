﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Foods
{
    class Lembas:Food
    {
        public override int Points { get=>3; }
    }
}
