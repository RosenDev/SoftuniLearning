﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Foods
{
    class HoneyCake:Food
    {
        public override int Points { get=>5; }
    }
}
