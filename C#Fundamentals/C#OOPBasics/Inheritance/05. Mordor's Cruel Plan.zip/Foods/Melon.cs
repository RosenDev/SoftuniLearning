﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Foods
{
    class Melon:Food
    {
        public override int Points { get=>1; }
    }
}
