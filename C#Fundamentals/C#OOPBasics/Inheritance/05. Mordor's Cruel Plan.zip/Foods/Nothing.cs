﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Foods
{
    class Nothing:Food
    {
        public override int Points { get=>-1; }
    }
}
