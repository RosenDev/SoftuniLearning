﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Foods
{
    public class Cram : Food
    {
        public override int Points { get=>2; }
    }
}
