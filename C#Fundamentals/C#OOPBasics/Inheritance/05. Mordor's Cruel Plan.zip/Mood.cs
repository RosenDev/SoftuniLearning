﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
  public abstract class Mood
    {
       
        public abstract string Value { get; }
    }
}
