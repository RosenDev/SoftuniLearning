﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    public abstract class Food
     {
         public abstract int Points { get; }

     }
}
