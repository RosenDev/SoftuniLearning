﻿using System;
using System.Collections.Generic;
using System.Text;
using InheritanceExercise.Moods;

namespace InheritanceExercise
{
    class MoodFactory
    {
        public static Mood CreateMood(int points)
        {
            if (points<-5)
            {
                return new Angry();
            }else if (points>=-5&&points<=0)
            {
                return new Sad();

            }else if (points >= 1 && points <= 15)
            {
                return new Happy();
            }
           return new JavaScript();
        }
    }
}
