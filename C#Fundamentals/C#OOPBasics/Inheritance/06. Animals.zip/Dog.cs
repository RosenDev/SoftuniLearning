﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class Dog:Animal
    {
        public override void ProduceSound()
        {
            Console.WriteLine("Woof!");
        }
        public Dog(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }

        public override string Type { get=>"Dog"; }
        public override string Name { get; set; }
        public override int Age { get; set; }
        public override string Gender { get; set; }
    }
}
