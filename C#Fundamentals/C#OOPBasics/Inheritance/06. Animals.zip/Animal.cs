﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    abstract class Animal:ISoundProducable
    {
       public abstract string Type { get; }
       public abstract string Name { get;  set; }
       public abstract int Age { get; set; }
        public abstract string Gender { get; set; }

        public virtual void ProduceSound()
        {
            Console.WriteLine("undefined");
        }
    }
}
