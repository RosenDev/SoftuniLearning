﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class Frog:Animal
    {
        public override void ProduceSound()
        {
            Console.WriteLine("Ribbit");
        }

        public Frog(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }

        public override string Type { get=>"Frog"; }
        public override string Name { get; set; }
        public override int Age { get; set; }
        public override string Gender { get; set; }

    }
}
