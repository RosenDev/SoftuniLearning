﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class Kitten:Cat
    {
        public  override string Type { get=>"Kitten"; }
        

        public override void ProduceSound()
        {
            Console.WriteLine("Meow");
        }

        public Kitten(string name, int age) : base(name, age, "Female")
        {

        }
    }
}
