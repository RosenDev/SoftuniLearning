﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class Tomcat:Cat
    {
        public override string Type { get=>"Tomcat"; }
        public override void ProduceSound()
        {
            Console.WriteLine("MEOW");
        }

        public Tomcat(string name, int age) : base(name, age, "Male")
        {
        }
    }
}
