﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class AnimalFactory
    {
        public static Animal CreateAnimal(string type,string name, int age, string gender)
        {
            switch (type.ToLower())
            {
                case "frog":
                    return new Frog(name,age,gender);
                case "cat":
                    return new Cat(name,age,gender);
                case "dog":
                    return  new Dog(name,age,gender);
                case "kitten":
                    return new Kitten(name,age);
                case "tomcat":
                    return new Tomcat(name,age);
                default:
                    throw new Exception();
            }
        }
    }
}
