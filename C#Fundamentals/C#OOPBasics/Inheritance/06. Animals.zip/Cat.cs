﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
    class Cat:Animal
    {
        public Cat(string name, int age, string gender)
        {
            Name = name;
            Age = age;
            Gender = gender;
        }

        public override void ProduceSound()
        {
            Console.WriteLine("Meow meow");
        }

        public override string Type { get=>"Cat";
        }
        public override string Name { get; set; }
        public override int Age { get; set; }
        public override string Gender { get; set; }
    }
}
