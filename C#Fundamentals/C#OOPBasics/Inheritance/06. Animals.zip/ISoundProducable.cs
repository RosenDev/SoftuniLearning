﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise
{
 public interface ISoundProducable
 {
     void ProduceSound();

 }
}
