﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;

namespace InheritanceExercise
{
   public class Program
    {
        static void Main(string[] args)
        {var animals = new List<Animal>();
            var input = Console.ReadLine();
            while (input!= "Beast!")
            {
                int a;
                var info = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);
                if (info.Length<3||!int.TryParse(info[1],out a)||int.Parse(info[1])<0)
                {
                    Console.WriteLine("Invalid input!");
                    input = Console.ReadLine();
                    continue;
                }

                try
                {
                    var animal = AnimalFactory.CreateAnimal(input, info[0], int.Parse(info[1]), info[2]);
                    animals.Add(animal);
                }
                catch (Exception e)
                {
                    Console.WriteLine("Invalid input!");
                }
               
                input = Console.ReadLine();
            }
            animals.ForEach(x=>
            {
                Console.WriteLine($"{x.Type}\n{x.Name} {x.Age} {x.Gender}");
                x.ProduceSound();
            });
        }
    }
}
