﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InheritanceExercise.Exceptions
{
    class InvalidSongException : Exception
    {
        public InvalidSongException(string message= "Invalid song.") : base(message)
        {
        }
    }
}
