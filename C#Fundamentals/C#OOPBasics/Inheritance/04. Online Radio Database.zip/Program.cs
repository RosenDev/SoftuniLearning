﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InheritanceExercise
{
   public class Program
    {
        static void Main(string[] args)
        {
            var playList = new List<Song>();
            var songsCount = int.Parse(Console.ReadLine());
            for (int s = 0; s < songsCount; s++)
            {
                try
                {
                    var song = Console.ReadLine().Split(";", StringSplitOptions.RemoveEmptyEntries).ToSong();
                    playList.Add(song);

                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                    continue;
                }


                Console.WriteLine($"Song added.");


            }
            Console.WriteLine($"Songs added: {playList.Count}");
            var timespan = new TimeSpan(0,playList.Sum(x=>x.Minutes),playList.Sum(x=>x.Seconds));
            Console.WriteLine($"Playlist length: {timespan.Hours}h {timespan.Minutes}m {timespan.Seconds}s");
        }
    }
}
