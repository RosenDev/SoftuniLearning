﻿using System;
using System.Collections.Generic;
using System.Text;
using InheritanceExercise.Exceptions;

namespace InheritanceExercise
{
  static  class StringArrayMethods
    {
        public static Song ToSong(this string[]array)
        {
            int minutes=-1;
            int seconds;
            var isMinutes = int.TryParse(array[2].Split(":")[0],out minutes);
            var isSeconds = int.TryParse(array[2].Split(":")[1], out seconds);
            if (!isMinutes||!isSeconds)
            {
                throw new InvalidSongLengthException();
            }
return new Song(array[0],array[1],minutes,seconds);
        }
    }
}
