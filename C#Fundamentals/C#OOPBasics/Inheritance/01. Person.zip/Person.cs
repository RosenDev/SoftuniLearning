﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InherterenceExercise
{
   public class Person
   {
       private int age;
       private string name;

      protected virtual int Age
       {
           get => age;
           set
           {
               if (value<=0)
               {
                   throw new ArgumentException("Age must be positive!");
               }

               age = value;
           }
       }

      protected virtual string Name
       {
           get => name;
           set
           {
               if (value.Length < 3)
               {
                   throw new ArgumentException("Name's length should not be less than 3 symbols!");
               }

               name = value;
           }
       }

       public Person( string name,int age)
       {
           this.Name = name;
            this.Age = age;
           
       }
   }
}
