﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace InherterenceExercise
{
    class Book

    {
        private string title;
        private string author;
        private decimal price;

        public string Title
        {
            get => title;
            set
            {
                if (value.Length<3)
                {
                    throw new ArgumentException("Title not valid!");
                }

                title = value;
            }
        }

        public string Author
        {
            get => author;
            set
            {
                if (value.Any(x=>char.IsDigit(x)))
                {
                    throw new ArgumentException("Author not valid!");
                }

                author = value;
            }
        }

        public Book(string author, string title, decimal price)
        {
            this.Author = author;
            this.Title = title;
          
            this.Price = price;
        }

        public virtual decimal Price
        {
            get => price;
            set
            {
                if (value<=0)
                {
                    throw new ArgumentException("Price not valid!");
                }

                price = value;
            }
        }

        public override string ToString()
        {
            return $"Type: Book\nTitle: {Title}\nAuthor: {Author}\nPrice: {Price:f2}";
        }
    }
}
