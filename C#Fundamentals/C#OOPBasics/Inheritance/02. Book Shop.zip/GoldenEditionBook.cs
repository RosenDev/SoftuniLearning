﻿using System;
using System.Collections.Generic;
using System.Text;

namespace InherterenceExercise
{
    class GoldenEditionBook:Book
    {
        public override decimal Price { get=>base.Price; set=>base.Price=value+value*0.3m; }

        public GoldenEditionBook(string author, string title, decimal price) : base(author, title, price)
        {
            Price = price;
        }
        public override string ToString()
        {
            return $"Type: GoldenEditionBook\nTitle: {Title}\nAuthor: {Author}\nPrice: {Price:f2}";
        }
    }
}
