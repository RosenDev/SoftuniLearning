﻿using System;
using System.Linq;

namespace P03_JediGalaxy
{
    class Program
    {
        static void Main()
        {
            int[] dimestions = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
            int rows = dimestions[0];
            int cols = dimestions[1];

            int[,] matrix = new int[rows, cols];

            ReadMatrix(rows, cols, matrix);

            string command = Console.ReadLine();
            long sum = 0;
            while (command != "Let the Force be with you")
            {
                int[] ivoPosition = command.Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                int[] enemyPosition = Console.ReadLine().Split(new string[] { " " }, StringSplitOptions.RemoveEmptyEntries).Select(int.Parse).ToArray();
                int enemyXPosition = enemyPosition[0];
                int enemyYPosition = enemyPosition[1];

                while (enemyXPosition >= 0 && enemyYPosition >= 0)
                {
                    if (IsValid(enemyXPosition, matrix, enemyYPosition))
                    {
                        matrix[enemyXPosition, enemyYPosition] = 0;
                    }
                    enemyXPosition--;
                    enemyYPosition--;
                }

                int ivoXPosition = ivoPosition[0];
                int ivoYPosition = ivoPosition[1];

                while (ivoXPosition >= 0 && ivoYPosition < matrix.GetLength(1))
                {
                    if (IsValid(ivoXPosition,matrix,ivoYPosition))
                    {
                        sum += matrix[ivoXPosition, ivoYPosition];
                    }

                    ivoYPosition++;
                    ivoXPosition--;
                }

                command = Console.ReadLine();
            }

            Console.WriteLine(sum);

        }

        private static void ReadMatrix(int x, int y, int[,] matrix)
        {
            int number = 0;
            for (int i = 0; i < x; i++)
            {
                for (int j = 0; j < y; j++)
                {
                    matrix[i, j] = number++;
                }
            }
        }

        private static bool IsValid(int enemyXPosition, int[,] matrix, int enemyYPosition)
        {
            return enemyXPosition >= 0 && enemyXPosition < matrix.GetLength(0) && enemyYPosition >= 0 && enemyYPosition < matrix.GetLength(1);
        }
    }
}
