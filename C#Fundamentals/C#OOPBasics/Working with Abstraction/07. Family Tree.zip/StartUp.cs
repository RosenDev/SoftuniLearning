﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace DefiningClasses
{

  public  class StartUp
  {
      private static List<Human> persons;
        static void Main(string[] args)
        {persons = new List<Human>();
            var relationships = new List<string>();
            string info = Console.ReadLine();
            var input = Console.ReadLine();
            while (input!="End")
            {
                if (!input.Contains("-"))
                {
                    var arg = input.Split(" ");
                    var name = arg[0] + " " + arg[1];
                    var birthday = arg[2];
                    persons.Add(new Human(name,birthday));
                    input = Console.ReadLine();
                    continue;
                }
                relationships.Add(input);
                input = Console.ReadLine();

            }

            foreach (var relationship in relationships)
            {
                var argums = relationship.Split(" - ", StringSplitOptions.RemoveEmptyEntries);
                var parent = GetPerson(argums[0]);
                var child = GetPerson(argums[1]);
                if (!parent.Children.Exists(x=>x.Name==child.Name))
                {
                    parent.Children.Add(child);
                }
                if (!child.Parents.Exists(x => x.Name == parent.Name))
                {
                    child.Parents.Add(parent);
                }
            }

            Console.WriteLine(GetPerson(info));
            Console.WriteLine($"Parents:");
            foreach (var parent in GetPerson(info).Parents)
            {
                Console.WriteLine(parent);
            }
            Console.WriteLine($"Children:");
            foreach (var VARIABLE in GetPerson(info).Children)
            {
                Console.WriteLine(VARIABLE);
            }
        }

        private static Human GetPerson(string s)
        {
            
            if (s.Contains("/"))
            {
                 var person=persons.FirstOrDefault(x => x.Birthday == s);
                return person;
            }

            return persons.FirstOrDefault(x=>x.Name==s);
        }
    }
}
