﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace DefiningClasses
{
    class Human
    {
        public List<Human> Parents { get; set; }
        public List<Human> Children { get; set; }
        public string Birthday { get; set; }
        public string Name { get; set; }
        public override string ToString()
        {
            return $"{Name} {Birthday}";
        }

        public Human(string name,string birthday)
        {
            Parents= new List<Human>();
            Children= new List<Human>();
            Name = name;
            Birthday = birthday;
        }

    }
}
