﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class DateModifier
    {
        private DateTime date1;
        private DateTime date2;
      
        public DateTime Date1 { get=>date1; set=>date1=value; }
        public DateTime Date2 { get=>date2; set=>date2=value; }
        public DateModifier(DateTime date1, DateTime date2)
        {
            this.Date1 = date1;
            this.Date2 = date2;
        }

        public override string ToString()
        {
            return Math.Abs((date2.Date-date1.Date).TotalDays).ToString();
        }
    }
}
