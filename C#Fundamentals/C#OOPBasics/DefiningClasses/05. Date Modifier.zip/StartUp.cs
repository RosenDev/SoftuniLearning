﻿using System;
using System.Globalization;
using System.Linq;

namespace DefiningClasses
{

  public  class StartUp
    {
        static void Main(string[] args)
        {
            var date1 = DateTime.ParseExact(Console.ReadLine(), "yyyy MM dd", CultureInfo.InvariantCulture);
            var date2 = DateTime.ParseExact(Console.ReadLine(), "yyyy MM dd", CultureInfo.InvariantCulture);
            Console.WriteLine(new DateModifier(date1,date2));
        }
    }
}
