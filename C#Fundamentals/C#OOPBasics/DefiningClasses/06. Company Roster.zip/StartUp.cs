﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;

namespace DefiningClasses
{

  public  class StartUp
    {
        static void Main(string[] args)
        {
            var employees = new List<Employee>();
            var lines = int.Parse(Console.ReadLine());
            for (int i = 0; i < lines; i++)
            {
                var input = Console.ReadLine().Split(" ",StringSplitOptions.RemoveEmptyEntries);
                if (input.Length==6)
                {
                    employees.Add(new Employee(input[0],decimal.Parse(input[1]),input[2],input[3],input[4],int.Parse(input[5])));

                }
                else if (input.Length == 4)
                {
                   employees.Add(new Employee(input[0],decimal.Parse(input[1]),input[2],input[3]));
                    
                        
                    
                }else if (input.Length == 5)
                {
                    if (input[4].Contains("@"))
                    {
                        employees.Add(new Employee(input[0], decimal.Parse(input[1]), input[2], input[3],input[4]));
                    }
                    else
                    {
                        employees.Add(new Employee(input[0], decimal.Parse(input[1]), input[2], input[3],int.Parse(input[4])));
                    }
                }
            }

            var maxDepartment = employees.GroupBy(x => x.Department).ToDictionary(x => x.Key, y => y.Select(s =>s).ToList());

            foreach (var keyValuePair in maxDepartment.OrderByDescending(x=>x.Value.Average(y=>y.Salary)))
            {
                Console.WriteLine($"Highest Average Salary: {keyValuePair.Key}");
                foreach (var employee in keyValuePair.Value.OrderByDescending(x=>x.Salary))
                {
                    Console.WriteLine(employee);
                }
                return;
            }


        }
    }
}
