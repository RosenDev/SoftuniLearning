﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Employee
    {
   

        public string Name { get; set; }
        public int Age { get; set; }  
        public string Email { get; set; }
        public decimal Salary { get; set; }
        public string Position { get; set; }
        public string Department { get; set; }

        public Employee(string name, decimal salary, string position, string department)
        {
            Name = name;
            Salary = salary;
            Position = position;
            Department = department;
            Age = -1;
            Email = "n/a";
        }

        public Employee(string name,   decimal salary, string position, string department, string email, int age) :
            this(name,salary,position,department)
        {
            
            Age = age;
            Email = email;
            
            
           
        }
        public Employee(string name, decimal salary, string position, string department, string email):
            this(name,salary,position,department)
        {
            Email = email;
        }
        public Employee(string name, decimal salary, string position, string department, int age) :
            this(name, salary, position, department)
        {
            Age = age;
        }

        public override string ToString()
        {
            return $"{Name} {Salary:f2} {Email} {Age}";
        }
    }
}
