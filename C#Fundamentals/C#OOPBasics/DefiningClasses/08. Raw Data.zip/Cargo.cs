﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Cargo
    {
        public int Weight { get; set; }
        public string Type { get; set; }

    }
}
