﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;

namespace DefiningClasses
{

  public  class StartUp
  {
      
        static void Main(string[] args)
        {
        var cars= new List<Car>();
            var count = int.Parse(Console.ReadLine());
            for (int i = 0; i < count; i++)
            {
                
                var car = Console.ReadLine().Split();
                var model = car[0];
                var engineSpeed = int.Parse(car[1]);
                var enginePower = int.Parse(car[2]);
                var cargoWeight = int.Parse(car[3]);
                var cargoType = car[4];
                var cr = new Car(model,new Engine{Power = enginePower,Speed = engineSpeed},new Cargo{Type = cargoType,Weight = cargoWeight} );
                for (int j = 5; j < car.Length-1; j+=2)
                {
                    cr.Tiers.Add(new Tier{Age = double.Parse(car[j+1]),Pressure = double.Parse(car[j])});

                }
                 cars.Add(cr);

            }

            var cmd = Console.ReadLine();
            if (cmd=="fragile")
            {
                foreach (var VARIABLE in cars.FindAll(x => x.Cargo.Type == "fragile" && x.Tiers.Any(y => y.Pressure < 1)))
                {
                    Console.WriteLine(VARIABLE.Model);
                }
            }
            else
            {
                foreach (var VARIABLE in cars.FindAll(x => x.Cargo.Type == "flamable" && x.Engine.Power > 250))
                {
                    Console.WriteLine(VARIABLE.Model);
                }
                
            }
        }

      
    }
}
