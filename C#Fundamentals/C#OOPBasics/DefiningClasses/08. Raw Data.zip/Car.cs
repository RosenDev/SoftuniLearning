﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Car
    {
        public string Model { get; set; }
        public List<Tier> Tiers { get; set; }
        public Engine Engine { get; set; }
        public Cargo Cargo { get; set; }

        public Car(string model,  Engine engine, Cargo cargo)
        {
            Model = model;
            Tiers = new List<Tier>();
            Engine = engine;
            Cargo = cargo;
        }
    }
}
