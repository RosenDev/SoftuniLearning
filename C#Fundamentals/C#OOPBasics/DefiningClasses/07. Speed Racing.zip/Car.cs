﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    class Car
    {
        private string model;

        public Car(string model, double fuelAmount, double fuel)
        {
            Model = model;
            FuelAmount = fuelAmount;
            Fuel = fuel;
        }

        public override string ToString()
        {
            return $"{Model} {FuelAmount:f2} {TravelledDistance}";
        }

        public double FuelAmount { get; set; }
        public double Fuel { get; set; }
        public int TravelledDistance { get; set; }
        public string Model { get=>model; set=>model=value==model?model:value; }

        public bool Travel(int distance)
        {
            if (distance*Fuel<=FuelAmount)
            {

                this.FuelAmount -= distance * Fuel;
                this.TravelledDistance += distance;
                return true;

            }

            return false;
        }
    }
}
