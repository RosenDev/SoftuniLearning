﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;

namespace DefiningClasses
{

  public  class StartUp
  {
      
        static void Main(string[] args)
        {
            var cars = new List<Car>();
            var carsCount= int.Parse(Console.ReadLine());
            for (int c = 0; c < carsCount; c++)
            {
                var input = Console.ReadLine().Split();
                cars.Add(new Car(input[0],double.Parse(input[1]),double.Parse(input[2])));

            }

            var cmd = Console.ReadLine();
            while (cmd!="End")
            {
                if (!cars.Find(x=>x.Model==cmd.Split()[1]).Travel(int.Parse(cmd.Split()[2])))
                {
                    Console.WriteLine($"Insufficient fuel for the drive"); 
                }
                cmd = Console.ReadLine();
            }

            foreach (var car in cars)
            {
                Console.WriteLine(car);
            }
        }

      
    }
}
