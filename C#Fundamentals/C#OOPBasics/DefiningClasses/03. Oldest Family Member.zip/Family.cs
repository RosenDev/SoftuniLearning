﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DefiningClasses
{
    class Family
    {
        private List<Person> people;
        

        public Family()
        {
            this.people= new List<Person>();
        }

        public Person GetOldestMember()
        {
            var max = int.MinValue;
            foreach (var person in people)
            {
                if (person.Age>max)
                {
                    max = person.Age;
                }
            }

            return people.Find(x => x.Age == max);
        }

        public void AddMember(Person member)
        {

            people.Add(member);

        }
    }
}
