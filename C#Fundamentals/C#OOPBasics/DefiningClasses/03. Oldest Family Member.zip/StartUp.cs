﻿using System;
using System.Globalization;

namespace DefiningClasses
{

  public  class StartUp
    {
        static void Main(string[] args)
        {var family = new Family();
            var peopleCount = int.Parse(Console.ReadLine());
            for (int i = 0; i < peopleCount; i++)
            {
                var member = Console.ReadLine().Split(" ");
                family.AddMember(new Person(member[0],int.Parse(member[1])));
            }

            Console.WriteLine(family.GetOldestMember());
        }
    }
}
