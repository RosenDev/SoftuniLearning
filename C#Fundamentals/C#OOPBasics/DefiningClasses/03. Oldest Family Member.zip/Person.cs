﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Person
    {
        

        public Person()
        {
            this.Age = 1;
            this.Name = "No Name";
        }

        public Person(int age):
            this()

        {
           
            this.Age = age;
        }
        public Person( string name,int age):
            this(age)
        {
            this.Age = age;
            this.Name = name;
        }


        public override string ToString()
        {
            return $"{Name} {Age}";
        }

        private int age;
        private string name;
        public int Age { get=>this.age; set=>this.age=value; }
        public string Name { get=>name; set=>name=value; }
    }
}
