﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
   public class Parent
    {
        private string birthday;
        private string name;
        public string Birthday { get => birthday; set => birthday = value; }
        public string Name { get => name; set => name = value; }
        public override string ToString()
        {
            return $"{name} {birthday}";
        }

        public Parent(string birthday, string name)
        {

            Birthday = birthday;
            Name = name;
        }
    }
}
