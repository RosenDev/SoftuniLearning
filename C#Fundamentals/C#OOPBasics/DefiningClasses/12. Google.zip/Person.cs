﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Person
    {
        public List<Pokemon> Pokemons { get; set; }
        public List<Parent> Parents { get; set; }
        public List<Child> Children { get; set; }
        public Company Company { get; set; }
        public Car Car { get; set; }

        public Person( Company company, Car car)
        {
            Pokemons = new List<Pokemon>();
            Parents = new List<Parent>();
            Children = new List<Child>();
            Company = company;
            Car = car;
        }
    }
}
