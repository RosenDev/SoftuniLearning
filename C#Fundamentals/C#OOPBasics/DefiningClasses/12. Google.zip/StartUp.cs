﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Net.Http.Headers;

namespace DefiningClasses
{

  public  class StartUp
  {
      
        static void Main(string[] args)
        {
            var persons = new Dictionary<string,Person>();
            var input = Console.ReadLine();
            while (input?.ToLower()!="end")
            {
                var info = input.Split();
                var name = info[0];
                switch (info[1])
                {
                    case "car":
                        var car = new Car
                        {
                            Model = info[2],
                            Speed = int.Parse(info[3])
                        };
                        var person = new Person(null,car);
                        if (!persons.ContainsKey(name))
                        {
                         
                            persons.Add(name,person);
                        }
                        else
                        {
                            if (persons[name].Car==null)
                            {
                                persons[name].Car = car;
                            }
                        }
                      
                        break;
                    case "children":
                        var birthday = info[3];
                        var nameC = info[2];
                        if (!persons.ContainsKey(name))
                        {
                            var personC = new Person(null, null);
                            persons.Add(name,personC);
                            persons[name].Children.Add(new Child(birthday, nameC));
                        }
                        else
                        {
                         
                            persons[name].Children.Add(new Child(birthday,nameC));
                        }
                        break;
                    case "parents":
                        var birthdayP = info[3];
                        var nameP = info[2];
                        var personP= new Person(null,null);
                        if (!persons.ContainsKey(name))
                        {
                            persons.Add(name,personP);
                            persons[name].Parents.Add(new Parent(birthdayP, nameP));
                        }
                        else
                        {
                            persons[name].Parents.Add(new Parent(birthdayP,nameP));
                        }
                        break;
                    case "company":
                        if (!persons.ContainsKey(name))
                        {
                            persons.Add(name,new Person(new Company(info[2],info[3],decimal.Parse(info[4])), null));
                        }
                        else
                        {
                            persons[name].Company= new Company(info[2], info[3], decimal.Parse(info[4]));

                        }
                        break;
                    case "pokemon":
                        var skills = info[3];
                        var namePoke = info[2];
                        var personPoke = new Person(null, null);
                        if (!persons.ContainsKey(name))
                        {
                            persons.Add(name,personPoke);
                            persons[name].Pokemons.Add(new Pokemon(namePoke, skills));

                        }
                        else
                        {
                            persons[name].Pokemons.Add(new Pokemon(namePoke,skills));
                        }

                        break;
                }
                

                input = Console.ReadLine();
            }

            var arg = Console.ReadLine();
            if (persons.ContainsKey(arg))
            {
                Console.WriteLine(arg);
                Console.WriteLine("Company:");
                
                if (persons[arg].Company!=null)
                {
                    Console.WriteLine(persons[arg].Company);
                }
                Console.WriteLine("Car:");
                if (persons[arg].Car!=null)
                {
                    Console.WriteLine(persons[arg].Car);
                }
               
                Console.WriteLine("Pokemon:");
                foreach (var pokemon in persons[arg].Pokemons)
                {
                    Console.WriteLine(pokemon);
                }

                Console.WriteLine("Parents:");
                foreach (var parent in persons[arg].Parents)
                {
                    Console.WriteLine(parent);
                }

                Console.WriteLine("Children:");
                foreach (var child in persons[arg].Children)
                {
                    Console.WriteLine(child);
                }
            }
        }

      
    }
}
