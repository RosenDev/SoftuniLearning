﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
   public class Car
    {
        public override string ToString()
        {
            return $"{Model} {Speed}";
        }

        private string model;
        private int speed;
        public string Model { get=>model; set=>model=value; }
        public int Speed { get=>speed; set=>speed=value; }
       
    }
}
