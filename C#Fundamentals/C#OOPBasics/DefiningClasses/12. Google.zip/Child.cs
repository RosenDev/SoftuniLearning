﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
   public class Child
    {
        public override string ToString()
        {
            return $"{name} {birthday}";
        }

        private string birthday;
        private string name;
        public string Birthday { get=>birthday; set=>birthday=value; }
        public string Name { get=>name; set=>name=value; }

        public Child(string birthday, string name)
        {
         
            Birthday = birthday;
            Name = name;
        }
    }
}
