﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DefiningClasses
{
    public class Person
    {
        public Person(int age, string name)
        {
            this.Age = age;
            this.Name = name;
        }

        public Person()
        {
        }

        private int age;
        private string name;
        public int Age { get=>this.age; set=>this.age=value; }
        public string Name { get=>name; set=>name=value; }
    }
}
