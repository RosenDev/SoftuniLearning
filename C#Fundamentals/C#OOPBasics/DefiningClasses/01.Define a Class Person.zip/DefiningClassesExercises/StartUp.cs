﻿using System;

namespace DefiningClasses
{

   public class StartUp
    {
        static void Main(string[] args)
        {
         var pesho = new Person(12,"Pesho");
         var gosho = new Person(12,"Gosho");
         var stamat = new Person(12,"Stamat");
        }
    }
}
